import './App.css'
import MainRoutes from './Allroutes/mainroutes'

function App() {
  return <MainRoutes />
}

export default App
