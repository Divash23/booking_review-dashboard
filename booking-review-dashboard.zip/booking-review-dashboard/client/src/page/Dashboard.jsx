import { useEffect, useMemo, useState } from 'react'
import { RotateCcw, TriangleAlert } from 'lucide-react'
import Sidebar from '../Component/Sidebar'
import Header from '../Component/Header'
import PropertyFilter from '../Component/PropertyFilter'
import DateFilter from '../Component/DateFilter'
import ReviewStatistics from '../Component/ReviewStatistics'
import RatingsCard from '../Component/RatingsCard'
import PropertyPerformance from '../Component/PropertyPerformance'
import SentimentTrend from '../Component/SentimentTrend'
import InsightsCard from '../Component/InsightsCard'
import TopicChart from '../Component/TopicChart'
import ReviewList from '../Component/ReviewList'
import DataStatus from '../Component/DataStatus'
import {
  getAllProperty,
  getAllReview,
  getInsights,
  getPropertyPerformance,
  getScrapeStatus,
  getSentiment,
  getSummary,
  getTopics,
  getWeeklyRating,
  startReviewUpdate,
} from '../Api/api'
import { periodRange } from '../lib/utils'

const EMPTY_FILTERS = { property: 'All', startDate: '', endDate: '' }
const EMPTY_REVIEW_QUERY = { sentiment: 'All', topic: 'All', sort: 'newest', page: 1 }

const errorMessage = (error) =>
  error.response?.data?.message ||
  (error.code === 'ERR_NETWORK' ? 'Cannot reach the server. Start it with "npm run dev" inside the server folder.' : error.message)

function Dashboard() {
  const [properties, setProperties] = useState([])
  const [filters, setFilters] = useState(EMPTY_FILTERS)
  const [period, setPeriod] = useState('all')
  const [search, setSearch] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [reviewQuery, setReviewQuery] = useState(EMPTY_REVIEW_QUERY)
  const [refreshKey, setRefreshKey] = useState(0)
  const [dashboard, setDashboard] = useState({ request: null, data: null, error: '' })
  const [reviewState, setReviewState] = useState({ request: null, data: null, error: '' })
  const [status, setStatus] = useState(null)
  const [updating, setUpdating] = useState(false)
  const [notice, setNotice] = useState('')

  const dashboardRequest = useMemo(() => ({ filters, refreshKey }), [filters, refreshKey])
  const reviewRequest = useMemo(
    () => ({ params: { ...filters, ...reviewQuery, search: debouncedSearch, limit: 8 }, refreshKey }),
    [filters, reviewQuery, debouncedSearch, refreshKey]
  )

  useEffect(() => {
    getAllProperty()
      .then(setProperties)
      .catch(() => setProperties([]))
    getScrapeStatus()
      .then(setStatus)
      .catch(() => setStatus(null))
  }, [refreshKey])

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(search), 400)
    return () => clearTimeout(timer)
  }, [search])

  useEffect(() => {
    let ignore = false
    const current = dashboardRequest.filters

    Promise.all([
      getSummary(current),
      getWeeklyRating({ ...current, weeks: 8 }),
      getPropertyPerformance(current),
      getSentiment(current),
      getTopics(current),
      getInsights(current),
    ])
      .then(([summary, weekly, performance, sentiment, topics, insights]) => {
        if (!ignore) {
          setDashboard({ request: dashboardRequest, data: { summary, weekly, performance, sentiment, topics, insights }, error: '' })
        }
      })
      .catch((error) => {
        if (!ignore) setDashboard({ request: dashboardRequest, data: null, error: errorMessage(error) })
      })

    return () => {
      ignore = true
    }
  }, [dashboardRequest])

  useEffect(() => {
    let ignore = false
    getAllReview(reviewRequest.params)
      .then((data) => {
        if (!ignore) setReviewState({ request: reviewRequest, data, error: '' })
      })
      .catch((error) => {
        if (!ignore) setReviewState({ request: reviewRequest, data: null, error: errorMessage(error) })
      })
    return () => {
      ignore = true
    }
  }, [reviewRequest])

  useEffect(() => {
    if (!updating) return undefined
    const timer = setInterval(async () => {
      try {
        const latest = await getScrapeStatus()
        setStatus(latest)
        if (!latest.running) {
          setUpdating(false)
          const added = latest.properties.reduce((sum, p) => sum + (p.lastRun ? p.lastRun.ReviewsInserted : 0), 0)
          const failed = latest.properties.filter((p) => p.lastRun && ['failed', 'blocked'].includes(p.lastRun.Status))
          setNotice(
            failed.length
              ? `Update finished with problems for ${failed.map((p) => p.Name).join(', ')}. See Data Updates below.`
              : `Update finished: ${added} new review${added === 1 ? '' : 's'} added.`
          )
          setRefreshKey((key) => key + 1)
        }
      } catch (error) {
        setUpdating(false)
        setNotice(errorMessage(error))
      }
    }, 4000)
    return () => clearInterval(timer)
  }, [updating])

  const dashboardLoading = dashboard.request !== dashboardRequest
  const reviewsLoading = reviewState.request !== reviewRequest
  const data = dashboard.data

  const updateFilters = (changes) => {
    setFilters((current) => ({ ...current, ...changes }))
    setReviewQuery((current) => ({ ...current, page: 1 }))
  }

  const handlePeriodChange = (nextPeriod) => {
    setPeriod(nextPeriod)
    updateFilters(periodRange(nextPeriod))
  }

  const handleDateChange = (dates) => {
    setPeriod('custom')
    updateFilters(dates)
  }

  const handleSearchChange = (value) => {
    setSearch(value)
    setReviewQuery((current) => ({ ...current, page: 1 }))
  }

  const handleTopicClick = (topic) => {
    setReviewQuery((current) => ({ ...current, topic, sentiment: 'All', page: 1 }))
    document.getElementById('reviews')?.scrollIntoView({ behavior: 'smooth' })
  }

  const handleReset = () => {
    setFilters(EMPTY_FILTERS)
    setPeriod('all')
    setSearch('')
    setReviewQuery(EMPTY_REVIEW_QUERY)
  }

  const handleUpdate = async () => {
    setNotice('')
    try {
      await startReviewUpdate()
      setUpdating(true)
    } catch (error) {
      setNotice(errorMessage(error))
    }
  }

  const hasFilters = filters.property !== 'All' || filters.startDate || filters.endDate || search

  return (
    <div className="flex min-h-screen">
      <Sidebar />

      <main className="min-w-0 flex-1 px-4 py-6 sm:px-6 lg:px-8">
        <Header
          search={search}
          onSearchChange={handleSearchChange}
          onUpdate={handleUpdate}
          updating={updating}
          lastUpdated={status?.lastNewReviewAt}
          demo={Boolean(status?.sources?.some((source) => source.demo))}
        />

        <div className="mt-5 grid gap-3 sm:grid-cols-[minmax(0,260px)_minmax(0,360px)_auto] sm:items-center">
          <PropertyFilter properties={properties} value={filters.property} onChange={(property) => updateFilters({ property })} />
          <DateFilter startDate={filters.startDate} endDate={filters.endDate} onChange={handleDateChange} />
          {hasFilters && (
            <button type="button" onClick={handleReset} className="flex items-center gap-1.5 justify-self-start text-sm font-medium text-muted hover:text-ink">
              <RotateCcw size={14} />
              Reset filters
            </button>
          )}
        </div>

        {notice && <p className="mt-4 rounded-lg bg-brand-soft px-4 py-2.5 text-sm text-brand-dark">{notice}</p>}

        {dashboard.error && (
          <div className="mt-4 flex items-start gap-2.5 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            <TriangleAlert size={17} className="mt-0.5 shrink-0" />
            {dashboard.error}
          </div>
        )}

        {!data && !dashboard.error && (
          <div className="mt-5 grid gap-5 lg:grid-cols-12">
            <div className="card h-96 animate-pulse lg:col-span-5" />
            <div className="card h-96 animate-pulse lg:col-span-3" />
            <div className="card h-96 animate-pulse lg:col-span-4" />
          </div>
        )}

        {data && status && status.totalReviews === 0 && (
          <div className="card mt-5 p-8 text-center">
            <p className="font-semibold">No reviews collected yet</p>
            <p className="mt-1 text-sm text-muted">
              Run “npm run import:dataset” (open demo data) or “npm run scrape:full” (live Booking.com) in the server folder.
            </p>
          </div>
        )}

        {data && (
          <div className={`transition-opacity ${dashboardLoading ? 'opacity-60' : ''}`}>
            <div className="mt-5 grid gap-5 lg:grid-cols-12">
              <div className="lg:col-span-5">
                <ReviewStatistics summary={data.summary} weekly={data.weekly} period={period} onPeriodChange={handlePeriodChange} />
              </div>
              <div className="lg:col-span-3">
                <RatingsCard summary={data.summary} topics={data.topics} />
              </div>
              <div className="lg:col-span-4">
                <PropertyPerformance performance={data.performance} selected={filters.property} onSelect={(property) => updateFilters({ property })} />
              </div>
            </div>

            <div className="mt-5 grid gap-5 lg:grid-cols-12">
              <div className="lg:col-span-7">
                <SentimentTrend weekly={data.weekly} sentiment={data.sentiment} />
              </div>
              <div className="lg:col-span-5">
                <InsightsCard insights={data.insights} onTopicClick={handleTopicClick} />
              </div>
            </div>

            <div className="mt-5">
              <TopicChart topics={data.topics} onTopicClick={handleTopicClick} />
            </div>
          </div>
        )}

        <div className="mt-5">
          {reviewState.error && !dashboard.error && <p className="mb-3 rounded-lg bg-red-50 px-4 py-2.5 text-sm text-red-700">{reviewState.error}</p>}
          <ReviewList
            data={reviewState.data}
            query={reviewQuery}
            onQueryChange={(changes) => setReviewQuery((current) => ({ ...current, ...changes }))}
            loading={reviewsLoading}
          />
        </div>

        {status && (
          <div className="mt-5">
            <DataStatus status={status} />
          </div>
        )}
      </main>
    </div>
  )
}

export default Dashboard
