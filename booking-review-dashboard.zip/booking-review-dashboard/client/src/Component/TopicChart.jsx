import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'

function TopicChart({ topics, onTopicClick }) {
  const data = topics.filter((topic) => topic.mentions > 0)

  return (
    <div id="topics" className="card scroll-mt-6 p-5">
      <h2 className="text-base font-semibold">Operational Topics</h2>
      <p className="mt-0.5 text-xs text-muted">
        How many reviews praise or complain about each area. Click a bar to read those reviews.
      </p>

      {data.length === 0 ? (
        <div className="mt-4 flex h-56 items-center justify-center rounded-xl bg-slate-50 text-sm text-muted">No topics found in this period</div>
      ) : (
        <div className="mt-4">
          <ResponsiveContainer width="100%" height={270}>
            <BarChart
              data={data}
              margin={{ top: 8, right: 8, left: -16, bottom: 0 }}
              onClick={(state) => state && state.activeLabel && onTopicClick(state.activeLabel)}
            >
              <CartesianGrid vertical={false} stroke="#eef2f7" />
              <XAxis dataKey="Topic" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} interval={0} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
              <Tooltip cursor={{ fill: '#f1f5f9' }} />
              <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="praise" name="Praised" fill="#16a34a" radius={[4, 4, 0, 0]} maxBarSize={28} isAnimationActive={false} className="cursor-pointer" />
              <Bar dataKey="issues" name="Complained about" fill="#dc2626" radius={[4, 4, 0, 0]} maxBarSize={28} isAnimationActive={false} className="cursor-pointer" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  )
}

export default TopicChart
