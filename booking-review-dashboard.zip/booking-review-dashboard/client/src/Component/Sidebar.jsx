import { useState } from 'react'
import { Building2, Database, Hotel, LayoutDashboard, Lightbulb, MessageSquare, Tags, TrendingUp } from 'lucide-react'

const NAV_ITEMS = [
  { href: '#overview', label: 'Overview', icon: LayoutDashboard },
  { href: '#properties', label: 'Properties', icon: Building2 },
  { href: '#trends', label: 'Trends', icon: TrendingUp },
  { href: '#insights', label: 'Insights', icon: Lightbulb },
  { href: '#topics', label: 'Topics', icon: Tags },
  { href: '#reviews', label: 'Review feed', icon: MessageSquare },
  { href: '#data', label: 'Data updates', icon: Database },
]

function Sidebar() {
  const [active, setActive] = useState('#overview')

  return (
    <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col border-r border-line bg-white px-4 py-6 lg:flex">
      <div className="mb-8 flex items-center gap-2.5 px-2">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand text-white">
          <Hotel size={18} />
        </div>
        <div>
          <p className="text-[15px] font-semibold leading-tight">Azzurro Reviews</p>
          <p className="text-xs text-muted">Operations dashboard</p>
        </div>
      </div>

      <nav className="flex flex-col gap-1">
        {NAV_ITEMS.map(({ href, label, icon: Icon }) => (
          <a
            key={href}
            href={href}
            onClick={() => setActive(href)}
            className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
              active === href ? 'bg-brand-soft text-brand' : 'text-slate-600 hover:bg-slate-50 hover:text-ink'
            }`}
          >
            <Icon size={17} />
            {label}
          </a>
        ))}
      </nav>

      <div className="mt-auto rounded-xl bg-gradient-to-br from-brand to-brand-dark p-4 text-white">
        <p className="text-sm font-semibold">Booking.com reviews</p>
        <p className="mt-1 text-xs leading-relaxed text-blue-100">
          Olympic Hotel Paddington, Potts Point, Central Sydney and Darling Harbour.
        </p>
      </div>
    </aside>
  )
}

export default Sidebar
