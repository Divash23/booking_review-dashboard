import { useState } from 'react'
import { ChevronLeft, ChevronRight, Frown, Smile } from 'lucide-react'
import { SENTIMENT_STYLES, TOPICS, formatDate, initials, scoreColor, scoreText } from '../lib/utils'

const SENTIMENTS = ['All', 'Positive', 'Neutral', 'Negative']

const SORTS = [
  { key: 'newest', label: 'Newest first' },
  { key: 'lowest', label: 'Lowest score first' },
  { key: 'highest', label: 'Highest score first' },
]

function ReviewCard({ review }) {
  const [open, setOpen] = useState(false)
  const long = (review.PositiveText || '').length > 120 || (review.NegativeText || '').length > 120

  return (
    <article className="flex flex-col rounded-xl border border-line p-4">
      <div className="flex items-start gap-3">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-brand-soft text-xs font-semibold text-brand">
          {initials(review.ReviewerName)}
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold">{review.ReviewerName}</p>
          <p className="truncate text-xs text-muted">{review.ReviewerCountry || 'Country not shown'}</p>
        </div>
        <span className={`shrink-0 rounded-md px-1.5 py-0.5 text-sm font-semibold ${scoreColor(review.Rating)}`}>
          {scoreText(review.Rating)}
        </span>
      </div>

      <p className="mt-3 text-xs font-medium text-slate-700">{review.Property_id?.Name}</p>
      <p className="text-xs text-muted">
        Reviewed {formatDate(review.ReviewDate)}
        {review.RoomType ? ` · ${review.RoomType}` : ''}
      </p>
      {review.SourceHotel && <p className="text-[11px] text-amber-700">Demo review from {review.SourceHotel}</p>}

      {review.Title && <p className="mt-2 text-sm font-semibold">“{review.Title}”</p>}

      <div className="mt-2 space-y-2 text-sm leading-relaxed text-slate-600">
        {review.PositiveText && (
          <p className="flex gap-1.5">
            <Smile size={15} className="mt-0.5 shrink-0 text-positive" />
            <span className={open ? '' : 'line-clamp-3'}>{review.PositiveText}</span>
          </p>
        )}
        {review.NegativeText && (
          <p className="flex gap-1.5">
            <Frown size={15} className="mt-0.5 shrink-0 text-negative" />
            <span className={open ? '' : 'line-clamp-3'}>{review.NegativeText}</span>
          </p>
        )}
        {!review.PositiveText && !review.NegativeText && <p className="italic text-muted">The guest left a score without comments.</p>}
      </div>
      {long && (
        <button type="button" onClick={() => setOpen(!open)} className="mt-1 self-start text-xs font-medium text-brand hover:underline">
          {open ? 'Show less' : 'Read more'}
        </button>
      )}

      <div className="mt-auto flex flex-wrap gap-1.5 pt-3">
        <span className={`rounded-full px-2 py-0.5 text-[11px] font-medium ring-1 ring-inset ${SENTIMENT_STYLES[review.Sentiment]}`}>
          {review.Sentiment}
        </span>
        {review.IssueTopics.map((topic) => (
          <span key={`i-${topic}`} className="rounded-full bg-red-50 px-2 py-0.5 text-[11px] text-red-700">
            {topic}
          </span>
        ))}
        {review.PraiseTopics.filter((topic) => !review.IssueTopics.includes(topic)).map((topic) => (
          <span key={`p-${topic}`} className="rounded-full bg-green-50 px-2 py-0.5 text-[11px] text-green-700">
            {topic}
          </span>
        ))}
      </div>
    </article>
  )
}

function ReviewList({ data, query, onQueryChange, loading }) {
  const reviews = data?.reviews || []
  const page = data?.page || 1
  const totalPages = data?.totalPages || 0

  return (
    <div id="reviews" className="card scroll-mt-6 p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-semibold">Review Feed</h2>
          <p className="text-xs text-muted">{(data?.totalReviews || 0).toLocaleString()} reviews match your filters</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex rounded-lg bg-slate-100 p-1 text-xs font-medium">
            {SENTIMENTS.map((sentiment) => (
              <button
                key={sentiment}
                type="button"
                onClick={() => onQueryChange({ sentiment, page: 1 })}
                className={`rounded-md px-2.5 py-1 transition-colors ${
                  query.sentiment === sentiment ? 'bg-white text-ink shadow-sm' : 'text-slate-600 hover:text-ink'
                }`}
              >
                {sentiment}
              </button>
            ))}
          </div>
          <select
            value={query.topic}
            onChange={(event) => onQueryChange({ topic: event.target.value, page: 1 })}
            className="rounded-lg border border-line bg-white px-3 py-1.5 text-xs outline-none"
            aria-label="Filter by topic"
          >
            <option value="All">All topics</option>
            {TOPICS.map((topic) => (
              <option key={topic} value={topic}>
                {topic}
              </option>
            ))}
          </select>
          <select
            value={query.sort}
            onChange={(event) => onQueryChange({ sort: event.target.value, page: 1 })}
            className="rounded-lg border border-line bg-white px-3 py-1.5 text-xs outline-none"
            aria-label="Sort reviews"
          >
            {SORTS.map((sort) => (
              <option key={sort.key} value={sort.key}>
                {sort.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className={`mt-4 grid gap-4 transition-opacity sm:grid-cols-2 xl:grid-cols-4 ${loading ? 'opacity-50' : ''}`}>
        {reviews.map((review) => (
          <ReviewCard key={review._id} review={review} />
        ))}
      </div>

      {!loading && reviews.length === 0 && (
        <p className="mt-4 rounded-xl bg-slate-50 py-10 text-center text-sm text-muted">No reviews match these filters</p>
      )}

      {totalPages > 1 && (
        <div className="mt-5 flex items-center justify-end gap-3 text-sm">
          <span className="text-muted">
            Page {page} of {totalPages}
          </span>
          <button
            type="button"
            disabled={page <= 1}
            onClick={() => onQueryChange({ page: page - 1 })}
            className="rounded-lg border border-line p-1.5 hover:bg-slate-50 disabled:opacity-40"
            aria-label="Previous page"
          >
            <ChevronLeft size={16} />
          </button>
          <button
            type="button"
            disabled={page >= totalPages}
            onClick={() => onQueryChange({ page: page + 1 })}
            className="rounded-lg border border-line p-1.5 hover:bg-slate-50 disabled:opacity-40"
            aria-label="Next page"
          >
            <ChevronRight size={16} />
          </button>
        </div>
      )}
    </div>
  )
}

export default ReviewList
