import { LoaderCircle, RefreshCw, Search } from 'lucide-react'
import { timeAgo } from '../lib/utils'

function Header({ search, onSearchChange, onUpdate, updating, lastUpdated, demo }) {
  return (
    <header className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h1 className="flex flex-wrap items-center gap-2 text-2xl font-semibold tracking-tight">
          Guest Review Insights
          {demo && (
            <span className="rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-semibold text-amber-800">Includes demo data</span>
          )}
        </h1>
        <p className="mt-0.5 text-sm text-muted">
          Booking.com reviews for all four properties · last new review found {timeAgo(lastUpdated)}
        </p>
      </div>

      <div className="flex items-center gap-3">
        <label className="relative flex-1 sm:w-72 sm:flex-none">
          <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="search"
            value={search}
            onChange={(event) => onSearchChange(event.target.value)}
            placeholder="Search review text or guest"
            className="w-full rounded-full border border-line bg-white py-2 pl-9 pr-4 text-sm outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
          />
        </label>
        <button
          type="button"
          onClick={onUpdate}
          disabled={updating}
          className="flex shrink-0 items-center gap-2 rounded-full bg-brand px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-brand-dark disabled:opacity-60"
        >
          {updating ? <LoaderCircle size={16} className="animate-spin" /> : <RefreshCw size={16} />}
          <span className="hidden sm:inline">{updating ? 'Checking Booking.com' : 'Get new reviews'}</span>
        </button>
      </div>
    </header>
  )
}

export default Header
