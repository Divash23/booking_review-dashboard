import { CircleAlert, CircleCheck, CircleDashed } from 'lucide-react'
import { timeAgo } from '../lib/utils'

const STATUS = {
  success: { label: 'Up to date', icon: CircleCheck, style: 'text-positive' },
  partial: { label: 'Partly updated', icon: CircleAlert, style: 'text-amber-500' },
  failed: { label: 'Update failed', icon: CircleAlert, style: 'text-negative' },
  blocked: { label: 'Blocked by Booking.com', icon: CircleAlert, style: 'text-negative' },
}

function DataStatus({ status }) {
  return (
    <div id="data" className="card scroll-mt-6 p-5">
      <h2 className="text-base font-semibold">Data Updates</h2>
      <p className="mt-0.5 text-xs text-muted">
        {status.totalReviews.toLocaleString()} reviews stored. Each update only adds reviews that are not already saved.
      </p>

      {status.sources && status.sources.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-2">
          {status.sources.map((source) => (
            <span
              key={source.Source}
              className={`rounded-full px-2.5 py-1 text-xs font-medium ${source.demo ? 'bg-amber-100 text-amber-800' : 'bg-green-50 text-green-700'}`}
            >
              {source.Source}: {source.count.toLocaleString()}
            </span>
          ))}
        </div>
      )}

      <ul className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {status.properties.map((property) => {
          const run = property.lastRun
          const info = run ? STATUS[run.Status] || STATUS.failed : { label: 'Never updated', icon: CircleDashed, style: 'text-slate-400' }
          const Icon = info.icon
          return (
            <li key={property.Property_id} className="rounded-xl border border-line p-3">
              <p className="text-sm font-semibold">{property.Name}</p>
              <p className={`mt-1 flex items-center gap-1.5 text-xs font-medium ${info.style}`}>
                <Icon size={14} />
                {info.label}
              </p>
              {run && (
                <p className="mt-1 text-xs text-muted">
                  {run.Source && run.Source !== 'Booking.com' ? 'Imported' : 'Checked'} {timeAgo(run.FinishedAt)} · {run.ReviewsInserted} new
                </p>
              )}
              {run && run.Errors.length > 0 && <p className="mt-1 line-clamp-2 text-[11px] text-negative">{run.Errors[0]}</p>}
            </li>
          )
        })}
      </ul>
    </div>
  )
}

export default DataStatus
