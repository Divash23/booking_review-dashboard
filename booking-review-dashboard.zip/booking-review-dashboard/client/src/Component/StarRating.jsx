import { Star } from 'lucide-react'

function StarRating({ score = 0, size = 14 }) {
  const filled = Math.round((Number(score) || 0) / 2)

  return (
    <div className="flex items-center gap-0.5" aria-label={`${score} out of 10`}>
      {[1, 2, 3, 4, 5].map((star) => (
        <Star
          key={star}
          size={size}
          className={star <= filled ? 'fill-star text-star' : 'fill-slate-200 text-slate-200'}
        />
      ))}
    </div>
  )
}

export default StarRating
