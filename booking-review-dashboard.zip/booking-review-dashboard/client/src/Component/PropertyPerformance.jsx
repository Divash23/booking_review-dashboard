import { Building2, ExternalLink, TriangleAlert } from 'lucide-react'
import { ChangeBadge } from './ReviewStatistics'
import { scoreColor, scoreText } from '../lib/utils'

const TILE_COLORS = [
  'from-sky-400 to-brand',
  'from-lime to-emerald-400',
  'from-indigo-400 to-violet-500',
  'from-amber-300 to-orange-400',
]

function PropertyPerformance({ performance, selected, onSelect }) {
  const ranked = [...performance].sort((a, b) => (b.averageRating || 0) - (a.averageRating || 0))

  return (
    <div id="properties" className="card scroll-mt-6 p-5">
      <div className="flex items-center justify-between">
        <h2 className="text-base font-semibold">Property Performance</h2>
        {selected !== 'All' && (
          <button type="button" onClick={() => onSelect('All')} className="text-xs font-medium text-brand hover:underline">
            Show all
          </button>
        )}
      </div>
      <p className="mt-0.5 text-xs text-muted">Click a property to filter the whole page</p>

      <ul className="mt-4 space-y-3">
        {ranked.length === 0 && <li className="rounded-xl bg-slate-50 py-8 text-center text-sm text-muted">No properties loaded yet</li>}
        {ranked.map((property, index) => {
          const isSelected = selected === property.Property_id
          return (
            <li key={property.Property_id}>
              <div
                role="button"
                tabIndex={0}
                onClick={() => onSelect(isSelected ? 'All' : property.Property_id)}
                onKeyDown={(event) => event.key === 'Enter' && onSelect(isSelected ? 'All' : property.Property_id)}
                className={`flex w-full cursor-pointer gap-3 rounded-xl border p-3 text-left transition-colors ${
                  isSelected ? 'border-brand bg-brand-soft' : 'border-line hover:border-slate-300'
                }`}
              >
                <div className={`relative flex h-16 w-16 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br text-white ${TILE_COLORS[index % TILE_COLORS.length]}`}>
                  <Building2 size={24} />
                  <span className="absolute -left-1.5 -top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-brand text-[10px] font-bold text-white ring-2 ring-white">
                    {index + 1}
                  </span>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold">{property.Name}</p>
                      <p className="text-xs text-muted">{property.totalReviews} reviews in this period</p>
                    </div>
                    <span className={`shrink-0 rounded-md px-1.5 py-0.5 text-sm font-semibold ${scoreColor(property.averageRating)}`}>
                      {scoreText(property.averageRating)}
                    </span>
                  </div>
                  <div className="mt-1.5 flex flex-wrap items-center gap-1.5 text-[11px]">
                    <span className="text-muted">This week {scoreText(property.thisWeek.averageRating)}</span>
                    <ChangeBadge change={property.weeklyChange} suffix="" />
                  </div>
                  <div className="mt-1.5 flex flex-wrap items-center gap-1.5 text-[11px]">
                    {property.topIssue && (
                      <span className="flex items-center gap-1 rounded bg-red-50 px-1.5 py-0.5 font-medium text-red-700">
                        <TriangleAlert size={10} />
                        {property.topIssue.Topic} · {property.topIssue.percentage}%
                      </span>
                    )}
                    {property.BookingUrl && (
                      <a
                        href={property.BookingUrl}
                        target="_blank"
                        rel="noreferrer"
                        onClick={(event) => event.stopPropagation()}
                        className="flex items-center gap-0.5 rounded bg-slate-100 px-1.5 py-0.5 text-slate-600 hover:text-brand"
                      >
                        Booking.com <ExternalLink size={10} />
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </li>
          )
        })}
      </ul>
    </div>
  )
}

export default PropertyPerformance
