import { CalendarDays } from 'lucide-react'

function DateFilter({ startDate, endDate, onChange }) {
  return (
    <div className="flex items-center gap-2 rounded-lg border border-line bg-white px-3 py-2 text-sm">
      <CalendarDays size={16} className="shrink-0 text-slate-400" />
      <input
        type="date"
        value={startDate}
        max={endDate || undefined}
        onChange={(event) => onChange({ startDate: event.target.value, endDate })}
        className="min-w-0 flex-1 bg-transparent outline-none"
        aria-label="Start date"
      />
      <span className="text-slate-400">to</span>
      <input
        type="date"
        value={endDate}
        min={startDate || undefined}
        onChange={(event) => onChange({ startDate, endDate: event.target.value })}
        className="min-w-0 flex-1 bg-transparent outline-none"
        aria-label="End date"
      />
    </div>
  )
}

export default DateFilter
