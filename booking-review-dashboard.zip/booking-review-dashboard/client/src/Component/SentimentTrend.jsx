import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { formatWeek } from '../lib/utils'

const BAR_COLORS = {
  Positive: 'bg-positive',
  Neutral: 'bg-neutral',
  Negative: 'bg-negative',
}

function SentimentTrend({ weekly, sentiment }) {
  return (
    <div id="trends" className="card scroll-mt-6 p-5">
      <h2 className="text-base font-semibold">Positive and Negative Trends</h2>
      <p className="mt-0.5 text-xs text-muted">Number of positive and negative reviews each week</p>

      <div className="mt-4 grid gap-6 md:grid-cols-[1fr_200px]">
        {weekly.length === 0 ? (
          <div className="flex h-56 items-center justify-center rounded-xl bg-slate-50 text-sm text-muted">No reviews in this period</div>
        ) : (
          <ResponsiveContainer width="100%" height={230}>
            <LineChart data={weekly} margin={{ top: 8, right: 8, left: -24, bottom: 0 }}>
              <CartesianGrid vertical={false} stroke="#eef2f7" />
              <XAxis dataKey="Week" tickFormatter={formatWeek} tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
              <Tooltip labelFormatter={(label) => `Week of ${formatWeek(label)}`} />
              <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
              <Line isAnimationActive={false} type="monotone" dataKey="Positive" stroke="#16a34a" strokeWidth={2.5} dot={{ r: 3 }} />
              <Line isAnimationActive={false} type="monotone" dataKey="Negative" stroke="#dc2626" strokeWidth={2.5} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        )}

        <div>
          <p className="text-xs font-medium text-muted">Sentiment in this period</p>
          <ul className="mt-3 space-y-4">
            {sentiment.map((item) => (
              <li key={item.Sentiment}>
                <div className="flex justify-between text-sm">
                  <span className="font-medium">{item.Sentiment}</span>
                  <span className="text-muted">
                    {item.count} · {item.percentage}%
                  </span>
                </div>
                <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-slate-100">
                  <div className={`h-full rounded-full ${BAR_COLORS[item.Sentiment]}`} style={{ width: `${item.percentage}%` }} />
                </div>
              </li>
            ))}
          </ul>
          <p className="mt-4 text-[11px] leading-relaxed text-muted">
            Positive = mostly 8+ scores with praise. Negative = low scores or clear complaints.
          </p>
        </div>
      </div>
    </div>
  )
}

export default SentimentTrend
