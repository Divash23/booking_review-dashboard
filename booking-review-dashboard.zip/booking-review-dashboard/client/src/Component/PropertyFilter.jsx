import { Building2 } from 'lucide-react'

function PropertyFilter({ properties, value, onChange }) {
  return (
    <label className="flex items-center gap-2 rounded-lg border border-line bg-white px-3 py-2 text-sm">
      <Building2 size={16} className="text-slate-400" />
      <select
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="min-w-0 flex-1 bg-transparent outline-none"
        aria-label="Filter by property"
      >
        <option value="All">All properties</option>
        {properties.map((property) => (
          <option key={property._id} value={property._id}>
            {property.Name}
          </option>
        ))}
      </select>
    </label>
  )
}

export default PropertyFilter
