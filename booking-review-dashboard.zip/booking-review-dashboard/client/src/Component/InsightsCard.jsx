import { CircleAlert, CircleCheck, Info } from 'lucide-react'

const TONES = {
  bad: { icon: CircleAlert, style: 'bg-red-50 text-red-800', iconStyle: 'text-negative' },
  good: { icon: CircleCheck, style: 'bg-green-50 text-green-800', iconStyle: 'text-positive' },
  info: { icon: Info, style: 'bg-brand-soft/70 text-ink', iconStyle: 'text-brand' },
}

function InsightsCard({ insights, onTopicClick }) {
  return (
    <div id="insights" className="card scroll-mt-6 p-5">
      <h2 className="text-base font-semibold">What guests are telling us</h2>

      <ul className="mt-4 space-y-2">
        {insights.messages.map((message) => {
          const tone = TONES[message.tone] || TONES.info
          const Icon = tone.icon
          return (
            <li key={message.text} className={`flex gap-2.5 rounded-lg px-3 py-2.5 text-sm ${tone.style}`}>
              <Icon size={16} className={`mt-0.5 shrink-0 ${tone.iconStyle}`} />
              <span>{message.text}</span>
            </li>
          )
        })}
      </ul>

      <div className="mt-5">
        <p className="text-xs font-semibold text-slate-700">
          Issues in negative reviews {insights.period} ({insights.negativeReviews} reviews)
        </p>
        {insights.issueBreakdown.length === 0 ? (
          <p className="mt-2 text-sm text-muted">No negative reviews with a clear topic.</p>
        ) : (
          <ul className="mt-3 space-y-2.5">
            {insights.issueBreakdown.map((row) => (
              <li key={row.Topic}>
                <button type="button" onClick={() => onTopicClick(row.Topic)} className="w-full text-left">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium hover:text-brand">{row.Topic}</span>
                    <span className="text-muted">
                      {row.percentage}% · {row.count}
                    </span>
                  </div>
                  <div className="mt-1 h-2 overflow-hidden rounded-full bg-slate-100">
                    <div className="h-full rounded-full bg-negative" style={{ width: `${row.percentage}%` }} />
                  </div>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}

export default InsightsCard
