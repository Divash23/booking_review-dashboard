import { Cell, Pie, PieChart, ResponsiveContainer } from 'recharts'
import StarRating from './StarRating'
import { scoreLabel, scoreText } from '../lib/utils'

function RatingsCard({ summary, topics }) {
  const average = summary.averageRating || 0
  const ring = [
    { name: 'score', value: average },
    { name: 'rest', value: Math.max(0, 10 - average) },
  ]
  const rows = topics.filter((topic) => topic.mentions > 0)

  return (
    <div className="card scroll-mt-6 p-5">
      <h2 className="text-base font-semibold">Ratings</h2>

      <div className="relative mx-auto mt-3 h-44 w-44">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={ring} dataKey="value" innerRadius={64} outerRadius={80} startAngle={90} endAngle={-270} stroke="none" isAnimationActive={false}>
              <Cell fill="#1f6feb" />
              <Cell fill="#e8eef7" />
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="text-[11px] font-medium text-muted">{scoreLabel(summary.averageRating)}</span>
          <span className="text-2xl font-semibold">
            {scoreText(summary.averageRating)}
            <span className="text-sm font-medium text-muted">/10</span>
          </span>
          <span className="text-[11px] text-muted">{summary.totalReviews.toLocaleString()} reviews</span>
        </div>
      </div>

      <p className="mt-4 text-[11px] font-medium uppercase tracking-wide text-muted">Average score when guests mention…</p>
      <ul className="mt-2 space-y-2.5">
        {rows.length === 0 && <li className="text-sm text-muted">No topics found yet</li>}
        {rows.map((row) => (
          <li key={row.Topic} className="flex items-center justify-between gap-2 text-sm">
            <span className="text-slate-600">{row.Topic}</span>
            <span className="flex items-center gap-2">
              <span className="w-7 text-right font-semibold">{scoreText(row.averageRating)}</span>
              <StarRating score={row.averageRating} size={12} />
            </span>
          </li>
        ))}
      </ul>
    </div>
  )
}

export default RatingsCard
