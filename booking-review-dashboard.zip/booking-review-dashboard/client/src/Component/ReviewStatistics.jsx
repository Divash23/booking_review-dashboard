import { ArrowDownRight, ArrowUpRight, Minus } from 'lucide-react'
import { Bar, BarChart, CartesianGrid, Cell, LabelList, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { formatWeek, scoreText } from '../lib/utils'

const PERIODS = [
  { key: 'week', label: 'This Week' },
  { key: 'month', label: 'This Month' },
  { key: '90days', label: '90 Days' },
  { key: 'all', label: 'All Time' },
]

export function ChangeBadge({ change, suffix = 'vs last week' }) {
  if (change === null || change === undefined) {
    return <span className="text-xs text-muted">No reviews last week to compare</span>
  }
  const Icon = change > 0 ? ArrowUpRight : change < 0 ? ArrowDownRight : Minus
  const style = change > 0 ? 'bg-lime text-ink' : change < 0 ? 'bg-red-50 text-negative' : 'bg-slate-100 text-slate-600'
  return (
    <span className={`inline-flex items-center gap-0.5 rounded-full px-2 py-0.5 text-xs font-semibold ${style}`}>
      <Icon size={13} />
      {change > 0 ? '+' : ''}
      {change.toFixed(2)} {suffix}
    </span>
  )
}

function StatBox({ label, value, suffix, children, highlight }) {
  return (
    <div className={`rounded-xl border p-4 ${highlight ? 'border-brand/30 bg-brand-soft/50' : 'border-line'}`}>
      <p className="text-xs font-medium text-muted">{label}</p>
      <p className="mt-1 text-2xl font-semibold tracking-tight">
        {value}
        {suffix && <span className="ml-1 text-sm font-medium text-muted">{suffix}</span>}
      </p>
      {children && <div className="mt-1.5">{children}</div>}
    </div>
  )
}

function ReviewStatistics({ summary, weekly, period, onPeriodChange }) {
  const current = summary.currentWeek
  const previous = summary.previousWeek

  return (
    <div id="overview" className="card scroll-mt-6 p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-base font-semibold">Review Statistics</h2>
        <div className="flex rounded-lg bg-slate-100 p-1 text-xs font-medium">
          {PERIODS.map((item) => (
            <button
              key={item.key}
              type="button"
              onClick={() => onPeriodChange(item.key)}
              className={`rounded-md px-2.5 py-1 transition-colors ${
                period === item.key ? 'bg-lime text-ink shadow-sm' : 'text-slate-600 hover:text-ink'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <StatBox label="This week's average" value={scoreText(current.averageRating)} suffix="/ 10" highlight>
          <ChangeBadge change={summary.weeklyChange} />
        </StatBox>
        <StatBox label="Last week's average" value={scoreText(previous.averageRating)} suffix="/ 10">
          <span className="text-xs text-muted">
            {current.totalReviews} reviews this week · {previous.totalReviews} last week
          </span>
        </StatBox>
        <StatBox label="Positive reviews" value={summary.positiveReviews.toLocaleString()}>
          <span className="text-xs font-semibold text-positive">{summary.positivePercentage}% of {summary.totalReviews} reviews</span>
        </StatBox>
        <StatBox label="Negative reviews" value={summary.negativeReviews.toLocaleString()}>
          <span className="text-xs font-semibold text-negative">{summary.negativePercentage}% of {summary.totalReviews} reviews</span>
        </StatBox>
      </div>

      <div className="mt-5">
        <p className="mb-2 text-xs font-medium text-muted">Average score by week (out of 10)</p>
        {weekly.length === 0 ? (
          <div className="flex h-52 items-center justify-center rounded-xl bg-slate-50 text-sm text-muted">No reviews in this period</div>
        ) : (
          <ResponsiveContainer width="100%" height={210}>
            <BarChart data={weekly} margin={{ top: 22, right: 4, left: -24, bottom: 0 }}>
              <CartesianGrid vertical={false} stroke="#eef2f7" />
              <XAxis dataKey="Week" tickFormatter={formatWeek} tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
              <YAxis domain={[0, 10]} ticks={[0, 2, 4, 6, 8, 10]} tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
              <Tooltip
                cursor={{ fill: '#f1f5f9' }}
                formatter={(value, name, item) => [`${value} / 10 (${item.payload.totalReviews} reviews)`, 'Average score']}
                labelFormatter={(label) => `Week of ${formatWeek(label)}`}
              />
              <Bar dataKey="Overall" isAnimationActive={false} radius={[6, 6, 0, 0]} maxBarSize={44}>
                {weekly.map((week, index) => (
                  <Cell key={week.Week} fill={index === weekly.length - 1 ? '#1f6feb' : index % 2 === 0 ? '#d4e83a' : '#9ec1fb'} />
                ))}
                <LabelList dataKey="Overall" position="top" formatter={(value) => Number(value).toFixed(1)} style={{ fontSize: 11, fontWeight: 600, fill: '#0f172a' }} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  )
}

export default ReviewStatistics
