import { Navigate, Route, Routes } from 'react-router-dom'
import Dashboard from '../page/Dashboard'

function MainRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

export default MainRoutes
