import axios from 'axios'

const API = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5050/api',
  timeout: 20000,
})

const cleanParams = (params = {}) =>
  Object.fromEntries(
    Object.entries(params).filter(([, value]) => value !== '' && value !== null && value !== undefined && value !== 'All')
  )

export const getAllProperty = async () => {
  const res = await API.get('/property/all-property')
  return res.data.properties
}

export const getAllReview = async (filters = {}) => {
  const res = await API.get('/review/all-review', { params: cleanParams(filters) })
  return res.data
}

export const getSummary = async (filters = {}) => {
  const res = await API.get('/dashboard/summary', { params: cleanParams(filters) })
  return res.data.summary
}

export const getWeeklyRating = async (filters = {}) => {
  const res = await API.get('/dashboard/weekly-rating', { params: cleanParams(filters) })
  return res.data.weeklyRating
}

export const getPropertyPerformance = async (filters = {}) => {
  const res = await API.get('/dashboard/property-performance', { params: cleanParams(filters) })
  return res.data.performance
}

export const getSentiment = async (filters = {}) => {
  const res = await API.get('/dashboard/sentiment', { params: cleanParams(filters) })
  return res.data.sentiment
}

export const getTopics = async (filters = {}) => {
  const res = await API.get('/dashboard/topics', { params: cleanParams(filters) })
  return res.data.topics
}

export const getInsights = async (filters = {}) => {
  const res = await API.get('/dashboard/insights', { params: cleanParams(filters) })
  return res.data.insights
}

export const startReviewUpdate = async (property) => {
  const res = await API.post('/scrape/run', cleanParams({ property }))
  return res.data
}

export const getScrapeStatus = async () => {
  const res = await API.get('/scrape/status')
  return res.data
}
