const express = require("express");
const cors = require("cors");
const morgan = require("morgan");
const settings = require("./Config/settings");
const Mongodb_Connection = require("./Config/db");
const ensureProperties = require("./Utils/ensureProperties");
const { runScraper } = require("./Scraper/runScraper");
const PropertyRoutes = require("./Routes/Property.routes");
const ReviewRoutes = require("./Routes/Review.routes");
const DashboardRoutes = require("./Routes/Dashboard.routes");
const ScrapeRoutes = require("./Routes/Scrape.routes");

let app = express();

app.use(cors());
app.use(express.json());
app.use(morgan("dev"));

app.get("/", (request, response) => {
    response.status(200).json({ message: "Booking Review Insights API is running" });
});

app.use("/api/property", PropertyRoutes);
app.use("/api/review", ReviewRoutes);
app.use("/api/dashboard", DashboardRoutes);
app.use("/api/scrape", ScrapeRoutes);

app.use((request, response) => {
    response.status(404).json({ message: "Route Not Found" });
});

app.use((error, request, response, next) => {
    console.log(error);
    response.status(500).json({ message: "Something went wrong on the server" });
});

const startSchedule = () => {
    if (!settings.scheduleMinutes) return;
    console.log(`Reviews will update every ${settings.scheduleMinutes} minutes`);
    setInterval(() => {
        runScraper({ mode: "incremental" }).catch((error) => console.log("Scheduled scrape:", error.message));
    }, settings.scheduleMinutes * 60 * 1000);
};

Mongodb_Connection()
    .then(async () => {
        console.log("MongoDB Connected");
        await ensureProperties();
        app.listen(settings.port, () => {
            console.log(`Server Running on Port ${settings.port}`);
        });
        startSchedule();
    })
    .catch((error) => {
        console.log("MongoDB Connection Failed:", error.message);
        process.exit(1);
    });
