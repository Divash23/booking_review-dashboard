const mongoose = require("mongoose");

let ScrapeRunSchema = new mongoose.Schema({
    Property_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Property"
    },
    PropertyName: {
        type: String
    },
    Source: {
        type: String,
        default: "Booking.com"
    },
    Mode: {
        type: String,
        enum: ["incremental", "full", "csv", "dataset"],
        default: "incremental"
    },
    Status: {
        type: String,
        enum: ["running", "success", "partial", "failed", "blocked"],
        default: "running"
    },
    Method: {
        type: String
    },
    StartedAt: {
        type: Date,
        default: Date.now
    },
    FinishedAt: {
        type: Date
    },
    PagesFetched: {
        type: Number,
        default: 0
    },
    ReviewsFound: {
        type: Number,
        default: 0
    },
    ReviewsInserted: {
        type: Number,
        default: 0
    },
    Duplicates: {
        type: Number,
        default: 0
    },
    Skipped: {
        type: Number,
        default: 0
    },
    Errors: {
        type: [String],
        default: []
    }
}, {
    timestamps: true
});

ScrapeRunSchema.index({ Property_id: 1, StartedAt: -1 });

let ScrapeRunModel = mongoose.model("ScrapeRun", ScrapeRunSchema);

module.exports = ScrapeRunModel;
