const mongoose = require("mongoose");

let PropertySchema = new mongoose.Schema({
    Name: {
        type: String,
        required: true,
        unique: true,
        trim: true
    },
    Slug: {
        type: String,
        required: true,
        unique: true
    },
    PageName: {
        type: String,
        required: true
    },
    CountryCode: {
        type: String,
        default: "au"
    },
    Location: {
        type: String,
        trim: true
    },
    BookingUrl: {
        type: String
    }
}, {
    timestamps: true
});

let PropertyModel = mongoose.model("Property", PropertySchema);

module.exports = PropertyModel;
