const mongoose = require("mongoose");
const { TOPICS } = require("../Utils/analyzeReview");

let ReviewSchema = new mongoose.Schema({
    Property_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Property",
        required: true
    },
    Source: {
        type: String,
        default: "Booking.com"
    },
    ExternalId: {
        type: String,
        required: true
    },
    ReviewerName: {
        type: String,
        trim: true,
        default: "Anonymous"
    },
    ReviewerCountry: {
        type: String,
        trim: true
    },
    Title: {
        type: String,
        trim: true
    },
    PositiveText: {
        type: String,
        trim: true
    },
    NegativeText: {
        type: String,
        trim: true
    },
    Rating: {
        type: Number,
        required: true,
        min: 1,
        max: 10
    },
    ReviewDate: {
        type: Date,
        required: true
    },
    StayDate: {
        type: String,
        trim: true
    },
    Nights: {
        type: Number
    },
    RoomType: {
        type: String,
        trim: true
    },
    TravellerType: {
        type: String,
        trim: true
    },
    TripType: {
        type: String,
        trim: true
    },
    SourceHotel: {
        type: String,
        trim: true
    },
    Sentiment: {
        type: String,
        enum: ["Positive", "Neutral", "Negative"]
    },
    SentimentScore: {
        type: Number
    },
    Topics: {
        type: [{ type: String, enum: TOPICS }],
        default: []
    },
    PraiseTopics: {
        type: [{ type: String, enum: TOPICS }],
        default: []
    },
    IssueTopics: {
        type: [{ type: String, enum: TOPICS }],
        default: []
    },
    FirstSeenAt: {
        type: Date,
        default: Date.now
    },
    LastSeenAt: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

ReviewSchema.index({ ExternalId: 1 }, { unique: true });
ReviewSchema.index({ Property_id: 1, ReviewDate: -1 });
ReviewSchema.index({ ReviewDate: -1 });

let ReviewModel = mongoose.model("Review", ReviewSchema);

module.exports = ReviewModel;
