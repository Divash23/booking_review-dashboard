const mongoose = require("mongoose");
const Mongodb_Connection = require("./Config/db");
const { importDataset } = require("./Scraper/importDataset");
const settings = require("./Config/settings");

const args = Object.fromEntries(
    process.argv.slice(2).map((arg) => {
        const [key, value] = arg.replace(/^--/, "").split("=");
        return [key, value === undefined ? true : value];
    })
);

const run = async () => {
    await Mongodb_Connection();
    console.log("MongoDB Connected");
    console.log(`Reading reviews from the open dataset ${settings.datasetName} ...`);

    const result = await importDataset({
        limit: args.limit ? Number(args.limit) : 2000,
        recent: !args["original-dates"]
    });

    console.table(
        result.runs.map((r) => ({
            Property: r.PropertyName,
            Status: r.Status,
            Found: r.ReviewsFound,
            New: r.ReviewsInserted,
            Duplicates: r.Duplicates
        }))
    );
    console.log(`Dataset size ${result.datasetSize}, fetched ${result.fetched}, skipped ${result.skipped}`);
    result.errors.forEach((error) => console.log(`! ${error}`));

    await mongoose.connection.close();
    process.exit(result.fetched === 0 ? 1 : 0);
};

run().catch(async (error) => {
    console.log("Dataset Import Failed:", error.message);
    await mongoose.connection.close();
    process.exit(1);
});
