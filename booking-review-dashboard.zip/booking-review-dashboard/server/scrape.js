const mongoose = require("mongoose");
const Mongodb_Connection = require("./Config/db");
const { runScraper } = require("./Scraper/runScraper");

const args = Object.fromEntries(
    process.argv.slice(2).map((arg) => {
        const [key, value] = arg.replace(/^--/, "").split("=");
        return [key, value === undefined ? true : value];
    })
);

const run = async () => {
    await Mongodb_Connection();
    console.log("MongoDB Connected");

    const runs = await runScraper({
        property: args.property,
        mode: args.full ? "full" : "incremental",
        maxPages: args.pages ? Number(args.pages) : undefined
    });

    console.log("\nSummary");
    console.table(
        runs.map((r) => ({
            Property: r.PropertyName,
            Status: r.Status,
            Method: r.Method || "-",
            Pages: r.PagesFetched,
            Found: r.ReviewsFound,
            New: r.ReviewsInserted,
            Duplicates: r.Duplicates,
            Skipped: r.Skipped
        }))
    );
    runs.forEach((r) => r.Errors.forEach((e) => console.log(`! ${r.PropertyName}: ${e}`)));

    await mongoose.connection.close();
    process.exit(runs.every((r) => r.Status === "failed" || r.Status === "blocked") ? 1 : 0);
};

run().catch(async (error) => {
    console.log("Scrape Failed:", error.message);
    await mongoose.connection.close();
    process.exit(1);
});
