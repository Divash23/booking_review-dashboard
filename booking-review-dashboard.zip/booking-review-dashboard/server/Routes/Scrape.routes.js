const express = require("express");
const ScrapeController = require("../Controller/Scrape.controller");

let ScrapeRoutes = express.Router();

ScrapeRoutes.post("/run", ScrapeController.run);
ScrapeRoutes.post("/import-dataset", ScrapeController.importdataset);
ScrapeRoutes.get("/status", ScrapeController.status);
ScrapeRoutes.get("/history", ScrapeController.history);

module.exports = ScrapeRoutes;
