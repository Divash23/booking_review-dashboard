const express = require("express");
const ReviewController = require("../Controller/Review.controller");

let ReviewRoutes = express.Router();

ReviewRoutes.get("/all-review", ReviewController.getallreview);
ReviewRoutes.get("/single-review/:rid", ReviewController.getsinglereview);

module.exports = ReviewRoutes;
