const express = require("express");
const PropertyController = require("../Controller/Property.controller");

let PropertyRoutes = express.Router();

PropertyRoutes.get("/all-property", PropertyController.getallproperty);
PropertyRoutes.get("/single-property/:pid", PropertyController.getsingleproperty);

module.exports = PropertyRoutes;
