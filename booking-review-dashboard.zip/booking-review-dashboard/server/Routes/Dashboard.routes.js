const express = require("express");
const DashboardController = require("../Controller/Dashboard.controller");

let DashboardRoutes = express.Router();

DashboardRoutes.get("/summary", DashboardController.summary);
DashboardRoutes.get("/weekly-rating", DashboardController.weeklyrating);
DashboardRoutes.get("/property-performance", DashboardController.propertyperformance);
DashboardRoutes.get("/sentiment", DashboardController.sentiment);
DashboardRoutes.get("/topics", DashboardController.topics);
DashboardRoutes.get("/insights", DashboardController.insights);

module.exports = DashboardRoutes;
