const settings = require("../Config/settings");

class BlockedError extends Error {
    constructor(message) {
        super(message);
        this.name = "BlockedError";
    }
}

const HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-GB,en;q=0.9"
};

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const backoffMs = (attempt) => 1000 * 2 ** attempt + Math.floor(Math.random() * 750);

const looksBlocked = (status, html) =>
    status === 202 ||
    status === 403 ||
    /awswaf|challenge-container|px-captcha|verify you are (a )?human/i.test(html);

const fetchOverHttp = async (url) => {
    let lastError = null;

    for (let attempt = 0; attempt <= settings.maxRetries; attempt++) {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), settings.requestTimeoutMs);
        try {
            const res = await fetch(url, { headers: HEADERS, signal: controller.signal, redirect: "follow" });
            const html = await res.text();

            if (res.ok && !looksBlocked(res.status, html)) {
                return html;
            }
            if (looksBlocked(res.status, html)) {
                throw new BlockedError(`Booking.com returned a bot check (HTTP ${res.status})`);
            }
            if (res.status === 404) {
                throw new Error("Page not found (HTTP 404). Check the property PageName in Config/properties.js");
            }

            lastError = new Error(`HTTP ${res.status}`);
            if (res.status === 429 || res.status >= 500) {
                const retryAfter = Number(res.headers.get("retry-after"));
                await sleep(Number.isFinite(retryAfter) && retryAfter > 0 ? retryAfter * 1000 : backoffMs(attempt));
                continue;
            }
            throw lastError;
        } catch (error) {
            if (error instanceof BlockedError || /HTTP 404/.test(error.message)) throw error;
            lastError = error.name === "AbortError" ? new Error(`Timed out after ${settings.requestTimeoutMs} ms`) : error;
            if (attempt < settings.maxRetries) await sleep(backoffMs(attempt));
        } finally {
            clearTimeout(timer);
        }
    }

    throw new Error(`Request failed after ${settings.maxRetries + 1} attempts: ${lastError ? lastError.message : "unknown error"}`);
};

const createFetcher = () => {
    let browser = null;
    let context = null;
    let preferBrowser = false;

    const openBrowser = async () => {
        if (context) return context;
        let playwright;
        try {
            playwright = require("playwright");
        } catch {
            throw new BlockedError("Booking.com blocked the plain request and Playwright is not installed. Run: npm install playwright && npx playwright install chromium");
        }
        try {
            browser = await playwright.chromium.launch({ headless: true });
        } catch (error) {
            throw new BlockedError(`Could not start the browser. Run: npx playwright install chromium (${error.message.split("\n")[0]})`);
        }
        context = await browser.newContext({ userAgent: HEADERS["User-Agent"], locale: "en-GB" });
        return context;
    };

    const fetchWithBrowser = async (url) => {
        const ctx = await openBrowser();
        const page = await ctx.newPage();
        try {
            await page.goto(url, { waitUntil: "domcontentloaded", timeout: 45000 });
            await page
                .waitForSelector(".review_list_new_item_block, [data-testid='review-card'], .c-review-block", { timeout: 20000 })
                .catch(() => null);
            const html = await page.content();
            if (looksBlocked(200, html)) {
                throw new BlockedError("Booking.com showed a bot check even in the browser");
            }
            return html;
        } finally {
            await page.close();
        }
    };

    const fetchPage = async (url) => {
        if (!preferBrowser) {
            try {
                return { html: await fetchOverHttp(url), method: "http" };
            } catch (error) {
                if (!(error instanceof BlockedError) || !settings.useBrowserFallback) throw error;
                preferBrowser = true;
            }
        }
        return { html: await fetchWithBrowser(url), method: "browser" };
    };

    const close = async () => {
        if (browser) await browser.close();
        browser = null;
        context = null;
    };

    return { fetchPage, close };
};

module.exports = { createFetcher, BlockedError, sleep };
