const ReviewModel = require("../Model/Review.Model");
const { analyzeReview } = require("../Utils/analyzeReview");

const FIELDS = [
    "ReviewerName", "ReviewerCountry", "Title", "PositiveText", "NegativeText", "Rating",
    "ReviewDate", "StayDate", "Nights", "RoomType", "TravellerType", "TripType", "SourceHotel"
];

const saveReviews = async (property, reviews, source = "Booking.com") => {
    if (reviews.length === 0) return { inserted: 0, duplicates: 0 };

    const now = new Date();
    const unique = [...new Map(reviews.map((review) => [review.ExternalId, review])).values()];

    const operations = unique.map((review) => {
        const data = { Property_id: property._id, Source: source, ExternalId: review.ExternalId, FirstSeenAt: now };
        FIELDS.forEach((field) => {
            if (review[field] !== undefined && review[field] !== "") data[field] = review[field];
        });
        Object.assign(data, analyzeReview(data));

        return {
            updateOne: {
                filter: { ExternalId: review.ExternalId },
                update: { $setOnInsert: data, $set: { LastSeenAt: now } },
                upsert: true
            }
        };
    });

    const result = await ReviewModel.bulkWrite(operations, { ordered: false });
    const inserted = result.upsertedCount || 0;

    return { inserted, duplicates: reviews.length - inserted };
};

module.exports = saveReviews;
