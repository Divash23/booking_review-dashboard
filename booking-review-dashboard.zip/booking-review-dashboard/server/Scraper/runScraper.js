const ensureProperties = require("../Utils/ensureProperties");
const { createFetcher, sleep } = require("./fetchPage");
const { scrapeProperty } = require("./scrapeProperty");
const { importDataset } = require("./importDataset");
const settings = require("../Config/settings");

let currentRun = null;

const isRunning = () => currentRun !== null;

const runExclusive = async (task) => {
    if (currentRun) {
        throw new Error("A review update is already running. Please wait for it to finish.");
    }
    currentRun = task();
    try {
        return await currentRun;
    } finally {
        currentRun = null;
    }
};

const runScraper = ({ property, mode = "incremental", maxPages, log = console.log } = {}) =>
    runExclusive(async () => {
        const properties = await ensureProperties();
        const selected = property
            ? properties.filter((p) => p.Slug === property || String(p._id) === String(property))
            : properties;

        if (selected.length === 0) {
            throw new Error(`Unknown property "${property}". Use one of: ${properties.map((p) => p.Slug).join(", ")}`);
        }

        const fetcher = createFetcher();
        const runs = [];
        try {
            for (const item of selected) {
                runs.push(await scrapeProperty(item, { fetcher, mode, maxPages, log }));
                await sleep(settings.requestDelayMs);
            }
        } finally {
            await fetcher.close();
        }
        return runs;
    });

const runDatasetImport = (options = {}) => runExclusive(() => importDataset(options));

module.exports = { runScraper, runDatasetImport, isRunning };
