const settings = require("../Config/settings");
const { cleanText } = require("../Utils/analyzeReview");
const ensureProperties = require("../Utils/ensureProperties");
const ScrapeRunModel = require("../Model/ScrapeRun.Model");
const saveReviews = require("./saveReviews");
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const DATASET_API = "https://datasets-server.huggingface.co/rows";
const PAGE_SIZE = 100;
const PAGE_DELAY_MS = 1000;
const DATASET_NEWEST_REVIEW = Date.UTC(2017, 7, 3);
const SOURCE = "Demo dataset (515K Hotel Reviews Europe)";

const clean = (value) => String(value || "").replace(/\s+/g, " ").trim();

const parseDatasetDate = (value) => {
    const match = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(clean(value));
    return match ? new Date(Date.UTC(Number(match[3]), Number(match[1]) - 1, Number(match[2]), 2)) : null;
};

const parseTags = (value) => {
    const tags = (String(value || "").match(/'([^']*)'/g) || []).map((tag) => clean(tag.replace(/'/g, "")));
    const nightsTag = tags.find((tag) => /^stayed \d+ nights?$/i.test(tag));
    const travellerTag = tags.find((tag) => /couple|solo|family|group|friends/i.test(tag));
    const tripTag = tags.find((tag) => /trip$/i.test(tag));
    const roomTag = tags.find(
        (tag) => tag !== nightsTag && tag !== travellerTag && tag !== tripTag && !/submitted from a mobile/i.test(tag)
    );
    return {
        Nights: nightsTag ? Number(nightsTag.match(/\d+/)[0]) : undefined,
        TravellerType: travellerTag,
        TripType: tripTag,
        RoomType: roomTag
    };
};

const propertyIndexFor = (hotelName, count) => {
    let hash = 0;
    for (const char of hotelName) hash = (hash * 31 + char.charCodeAt(0)) >>> 0;
    return hash % count;
};

const fetchRows = async (offset, length) => {
    const url = `${DATASET_API}?dataset=${encodeURIComponent(settings.datasetName)}&config=default&split=train&offset=${offset}&length=${length}`;
    let lastError = null;

    for (let attempt = 0; attempt <= settings.maxRetries + 1; attempt++) {
        let waitMs = 1000 * 2 ** attempt;
        try {
            const res = await fetch(url, { signal: AbortSignal.timeout(settings.requestTimeoutMs) });
            if (res.ok) return await res.json();
            lastError = new Error(`Dataset API returned HTTP ${res.status}`);
            if (res.status !== 429 && res.status < 500) throw lastError;
            if (res.status === 429) {
                const retryAfter = Number(res.headers.get("retry-after"));
                waitMs = Number.isFinite(retryAfter) && retryAfter > 0 ? retryAfter * 1000 : 5000 * 2 ** attempt;
            }
        } catch (error) {
            if (/HTTP 4\d\d/.test(error.message) && !/HTTP 429/.test(error.message)) throw error;
            lastError = error;
        }
        if (attempt <= settings.maxRetries) await sleep(Math.min(waitMs, 60000) + Math.floor(Math.random() * 500));
    }

    throw new Error(`Dataset API failed after ${settings.maxRetries + 2} attempts: ${lastError.message}`);
};

const toReview = (item, dayShiftMs) => {
    const row = item.row || {};
    const Rating = Number(row.Reviewer_Score);
    const originalDate = parseDatasetDate(row.Review_Date);
    if (!Rating || Rating < 1 || Rating > 10 || !originalDate) return null;

    return {
        ExternalId: `dataset:${item.row_idx}`,
        ReviewerName: "Booking.com guest",
        ReviewerCountry: clean(row.Reviewer_Nationality),
        PositiveText: cleanText(row.Positive_Review),
        NegativeText: cleanText(row.Negative_Review),
        Rating,
        ReviewDate: new Date(originalDate.getTime() + dayShiftMs),
        SourceHotel: clean(row.Hotel_Name),
        ...parseTags(row.Tags)
    };
};

const importDataset = async ({ limit = 2000, recent = true, log = console.log } = {}) => {
    const total = Math.min(20000, Math.max(100, parseInt(limit) || 2000));
    const properties = await ensureProperties();

    const first = await fetchRows(0, 1);
    const datasetSize = first.num_rows_total;
    const pages = Math.ceil(total / PAGE_SIZE);
    const stride = Math.floor(datasetSize / pages);

    const now = new Date();
    const today = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
    const dayShiftMs = recent ? today - DATASET_NEWEST_REVIEW : 0;

    const byProperty = properties.map(() => []);
    const errors = [];
    let fetched = 0;
    let skipped = 0;

    for (let page = 0; page < pages; page++) {
        const length = Math.min(PAGE_SIZE, total - page * PAGE_SIZE);
        try {
            const data = await fetchRows(page * stride, length);
            data.rows.forEach((item) => {
                const review = toReview(item, dayShiftMs);
                if (!review) {
                    skipped += 1;
                    return;
                }
                byProperty[propertyIndexFor(review.SourceHotel, properties.length)].push(review);
            });
            fetched += data.rows.length;
            log(`Dataset page ${page + 1}/${pages}: ${data.rows.length} rows`);
        } catch (error) {
            errors.push(`Page ${page + 1}: ${error.message}`);
            log(`Dataset page ${page + 1}/${pages} failed: ${error.message}`);
        }
        await sleep(PAGE_DELAY_MS);
    }

    const runs = [];
    for (let i = 0; i < properties.length; i++) {
        const saved = await saveReviews(properties[i], byProperty[i], SOURCE);
        runs.push(
            await ScrapeRunModel.create({
                Property_id: properties[i]._id,
                PropertyName: properties[i].Name,
                Source: SOURCE,
                Mode: "dataset",
                Method: "dataset-api",
                Status: errors.length === 0 ? "success" : fetched > 0 ? "partial" : "failed",
                FinishedAt: new Date(),
                PagesFetched: pages - errors.length,
                ReviewsFound: byProperty[i].length,
                ReviewsInserted: saved.inserted,
                Duplicates: saved.duplicates,
                Skipped: i === 0 ? skipped : 0,
                Errors: errors.slice(0, 5)
            })
        );
    }

    return { datasetSize, fetched, skipped, errors, runs };
};

module.exports = { importDataset, SOURCE };
