const fs = require("fs");
const path = require("path");
const settings = require("../Config/settings");
const ScrapeRunModel = require("../Model/ScrapeRun.Model");
const { parseReviews } = require("./parseReviews");
const saveReviews = require("./saveReviews");
const { BlockedError, sleep } = require("./fetchPage");

const SNAPSHOT_DIR = path.join(__dirname, "..", "logs", "snapshots");

const buildReviewListUrl = (property, offset) => {
    const params = new URLSearchParams({
        cc1: property.CountryCode,
        pagename: property.PageName,
        type: "total",
        sort: "f_recent_desc",
        rows: String(settings.rowsPerPage),
        offset: String(offset),
        lang: "en-gb"
    });
    if (settings.reviewLanguage) params.set("r_lang", settings.reviewLanguage);
    return `${settings.bookingBaseUrl}/reviewlist.html?${params.toString()}`;
};

const saveSnapshot = (property, html) => {
    try {
        fs.mkdirSync(SNAPSHOT_DIR, { recursive: true });
        const file = path.join(SNAPSHOT_DIR, `${property.Slug}-${Date.now()}.html`);
        fs.writeFileSync(file, html);
        return file;
    } catch {
        return null;
    }
};

const scrapeProperty = async (property, { fetcher, mode = "incremental", maxPages, log = () => {} }) => {
    const pageLimit = maxPages || (mode === "full" ? settings.maxPagesFull : settings.maxPagesIncremental);
    const run = await ScrapeRunModel.create({
        Property_id: property._id,
        PropertyName: property.Name,
        Mode: mode,
        Status: "running"
    });

    let blocked = false;

    try {
        for (let page = 0; page < pageLimit; page++) {
            const url = buildReviewListUrl(property, page * settings.rowsPerPage);
            let result;
            try {
                result = await fetcher.fetchPage(url);
            } catch (error) {
                blocked = error instanceof BlockedError;
                run.Errors.push(`Page ${page + 1}: ${error.message}`);
                break;
            }

            run.Method = result.method;
            run.PagesFetched += 1;
            const parsed = parseReviews(result.html, property.PageName);

            if (parsed.itemCount === 0) {
                if (page === 0) {
                    const file = saveSnapshot(property, result.html);
                    run.Errors.push(
                        `No reviews found on the first page. The page layout may have changed or the request was blocked.${file ? ` HTML saved to ${file}` : ""}`
                    );
                }
                break;
            }

            if (parsed.skipped > 0) {
                run.Skipped += parsed.skipped;
                run.Errors.push(`Page ${page + 1}: skipped ${parsed.skipped} incomplete review(s) (${parsed.problems.slice(0, 2).join("; ")})`);
                if (parsed.reviews.length === 0) saveSnapshot(property, result.html);
            }

            const saved = await saveReviews(property, parsed.reviews);
            run.ReviewsFound += parsed.reviews.length;
            run.ReviewsInserted += saved.inserted;
            run.Duplicates += saved.duplicates;
            log(`${property.Name}: page ${page + 1} → ${parsed.reviews.length} reviews, ${saved.inserted} new (${result.method})`);

            if (mode === "incremental" && saved.inserted === 0) break;
            if (parsed.itemCount < settings.rowsPerPage) break;

            await sleep(settings.requestDelayMs + Math.floor(Math.random() * 1000));
        }

        if (blocked) run.Status = run.ReviewsFound > 0 ? "partial" : "blocked";
        else if (run.Errors.length === 0) run.Status = "success";
        else run.Status = run.ReviewsFound > 0 ? "partial" : "failed";
    } catch (error) {
        run.Errors.push(error.message);
        run.Status = "failed";
    } finally {
        run.FinishedAt = new Date();
        await run.save();
    }

    return run;
};

module.exports = { scrapeProperty, buildReviewListUrl };
