const crypto = require("crypto");
const cheerio = require("cheerio");

const MONTHS = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];

const clean = (value) => String(value || "").replace(/\s+/g, " ").trim();

const textOf = ($el) => clean($el.first().text());

const stripLabel = (value) => clean(value).replace(/^(liked|disliked|positive|negative)\s*[·:.-]?\s*/i, "");

const NO_COMMENT = /there are no comments available/i;

const parseScore = (value) => {
    const match = /(?<!\d)(10|[1-9])(?:[.,](\d))?/.exec(clean(value));
    if (!match) return null;
    const score = Number(match[2] ? `${match[1]}.${match[2]}` : match[1]);
    return score >= 1 && score <= 10 ? score : null;
};

const monthIndex = (name) => MONTHS.findIndex((month) => month.startsWith(String(name).toLowerCase().slice(0, 3)));

const parseReviewDate = (value) => {
    const text = clean(value).replace(/^reviewed\s*:?\s*/i, "");
    let match = /(\d{1,2})\s+([a-z]+)\s+(\d{4})/i.exec(text);
    if (match && monthIndex(match[2]) >= 0) {
        return new Date(Date.UTC(Number(match[3]), monthIndex(match[2]), Number(match[1]), 2));
    }
    match = /([a-z]+)\s+(\d{1,2}),?\s+(\d{4})/i.exec(text);
    if (match && monthIndex(match[1]) >= 0) {
        return new Date(Date.UTC(Number(match[3]), monthIndex(match[1]), Number(match[2]), 2));
    }
    match = /(\d{4})-(\d{2})-(\d{2})/.exec(text);
    if (match) {
        return new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]), 2));
    }
    return null;
};

const parseNights = (value) => {
    const match = /(\d+)\s*nights?/i.exec(clean(value));
    return match ? Number(match[1]) : undefined;
};

const leafTexts = ($, $el) =>
    $el
        .find("*")
        .filter((_, node) => $(node).children().length === 0)
        .map((_, node) => clean($(node).text()))
        .get()
        .filter(Boolean);

const makeExternalId = (pageName, review) => {
    if (review.bookingId) return `booking:${review.bookingId}`;
    const fingerprint = [
        pageName,
        review.ReviewerName,
        review.ReviewerCountry,
        review.ReviewDate ? review.ReviewDate.toISOString().slice(0, 10) : "",
        review.Rating,
        review.Title,
        review.PositiveText,
        review.NegativeText
    ].join("|").toLowerCase();
    return `hash:${crypto.createHash("sha1").update(fingerprint).digest("hex")}`;
};

const parseClassicBlock = ($, $item) => {
    let PositiveText = "";
    let NegativeText = "";

    $item.find(".c-review__row").each((index, row) => {
        const $row = $(row);
        const body = clean($row.find(".c-review__body").first().text());
        if (!body || NO_COMMENT.test(body)) return;
        const label = clean($row.find(".c-review__prefix").first().text());
        const isNegative = /dislik/i.test(label) || $row.hasClass("lalala") || (!/lik/i.test(label) && index > 0);
        if (isNegative) NegativeText = NegativeText || body;
        else PositiveText = PositiveText || body;
    });

    const dates = $item.find(".c-review-block__date").map((_, el) => clean($(el).text())).get();
    const reviewedText = dates.find((value) => /reviewed/i.test(value)) || dates[dates.length - 1] || "";
    const stayBlock = $item.find(".c-review-block__stay-date").first();

    return {
        bookingId: $item.attr("data-review-url") || $item.find("[data-review-url]").attr("data-review-url") || null,
        ReviewerName: textOf($item.find(".bui-avatar-block__title")),
        ReviewerCountry: textOf($item.find(".bui-avatar-block__subtitle")),
        RoomType: textOf($item.find(".c-review-block__room-link .bui-list__body, .c-review-block__room-info-row .bui-list__body")),
        Nights: parseNights(stayBlock.text()),
        StayDate: textOf(stayBlock.find(".c-review-block__date")),
        TravellerType: textOf($item.find(".review-panel-wide__traveller_type .bui-list__body")),
        Title: textOf($item.find(".c-review-block__title")),
        Rating: parseScore($item.find(".bui-review-score__badge").first().text() || $item.find(".bui-review-score__badge").attr("aria-label")),
        ReviewDate: parseReviewDate(reviewedText),
        PositiveText,
        NegativeText
    };
};

const parseCardLayout = ($, $card) => {
    const pick = (testId) => $card.find(`[data-testid="${testId}"]`).first();
    const avatar = leafTexts($, pick("review-avatar"));
    const positive = stripLabel(pick("review-positive-text").text());
    const negative = stripLabel(pick("review-negative-text").text());

    return {
        bookingId: $card.attr("data-review-id") || $card.find("[data-review-id]").attr("data-review-id") || null,
        ReviewerName: avatar[0] || "",
        ReviewerCountry: avatar[1] || "",
        RoomType: clean(pick("review-room-name").text()),
        Nights: parseNights(pick("review-num-nights").text()),
        StayDate: clean(pick("review-stay-date").text()),
        TravellerType: clean(pick("review-traveler-type").text()),
        Title: clean(pick("review-title").text()),
        Rating: parseScore(pick("review-score").text()),
        ReviewDate: parseReviewDate(pick("review-date").text()),
        PositiveText: NO_COMMENT.test(positive) ? "" : positive,
        NegativeText: NO_COMMENT.test(negative) ? "" : negative
    };
};

const parseReviews = (html, pageName) => {
    const $ = cheerio.load(html);
    const raw = [];
    let layout = "none";

    const cards = $("[data-testid='review-card']");
    const classic = $("li.review_list_new_item_block");

    if (classic.length > 0) {
        layout = "classic";
        classic.each((_, item) => raw.push(parseClassicBlock($, $(item))));
    } else if (cards.length > 0) {
        layout = "cards";
        cards.each((_, card) => raw.push(parseCardLayout($, $(card))));
    } else if ($(".c-review-block").length > 0) {
        layout = "classic-blocks";
        $(".c-review-block").each((_, item) => raw.push(parseClassicBlock($, $(item))));
    }

    const reviews = [];
    const problems = [];

    raw.forEach((item, index) => {
        if (!item.Rating) {
            problems.push(`item ${index + 1}: missing or invalid score`);
            return;
        }
        if (!item.ReviewDate) {
            problems.push(`item ${index + 1}: missing or unreadable review date`);
            return;
        }
        const review = {
            ...item,
            ReviewerName: item.ReviewerName || "Anonymous",
            Title: item.Title.replace(/^[“"]|[”"]$/g, "")
        };
        review.ExternalId = makeExternalId(pageName, review);
        delete review.bookingId;
        reviews.push(review);
    });

    return { reviews, itemCount: raw.length, skipped: raw.length - reviews.length, problems, layout };
};

module.exports = { parseReviews, parseReviewDate, parseScore };
