const PropertyModel = require("../Model/Property.Model");
const PROPERTIES = require("../Config/properties");

const ensureProperties = async () => {
    const properties = [];
    for (const item of PROPERTIES) {
        const property = await PropertyModel.findOneAndUpdate(
            { Slug: item.Slug },
            { $set: item },
            { upsert: true, returnDocument: "after" }
        );
        properties.push(property);
    }
    return properties;
};

module.exports = ensureProperties;
