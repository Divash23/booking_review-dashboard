const mongoose = require("mongoose");
const { dayStart, dayEndExclusive } = require("./dates");
const { TOPICS } = require("./analyzeReview");

const escapeRegex = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const isSet = (value) => value !== undefined && value !== null && value !== "" && value !== "All";

const buildFilter = (query = {}, { ignoreDates = false } = {}) => {
    const { property, startDate, endDate, sentiment, topic, issue, search } = query;
    const filter = {};

    if (isSet(property)) {
        if (!mongoose.isValidObjectId(property)) {
            throw new Error("Invalid property id");
        }
        filter.Property_id = new mongoose.Types.ObjectId(property);
    }

    if (!ignoreDates && (isSet(startDate) || isSet(endDate))) {
        filter.ReviewDate = {};
        if (isSet(startDate)) {
            const start = dayStart(startDate);
            if (!start) throw new Error("startDate must look like YYYY-MM-DD");
            filter.ReviewDate.$gte = start;
        }
        if (isSet(endDate)) {
            const end = dayEndExclusive(endDate);
            if (!end) throw new Error("endDate must look like YYYY-MM-DD");
            filter.ReviewDate.$lt = end;
        }
    }

    if (isSet(sentiment)) {
        if (!["Positive", "Neutral", "Negative"].includes(sentiment)) {
            throw new Error("sentiment must be Positive, Neutral or Negative");
        }
        filter.Sentiment = sentiment;
    }

    if (isSet(topic)) {
        if (!TOPICS.includes(topic)) throw new Error(`Unknown topic: ${topic}`);
        filter.Topics = topic;
    }

    if (isSet(issue)) {
        if (!TOPICS.includes(issue)) throw new Error(`Unknown topic: ${issue}`);
        filter.IssueTopics = issue;
    }

    if (isSet(search) && String(search).trim()) {
        const pattern = { $regex: escapeRegex(String(search).trim()), $options: "i" };
        filter.$or = [{ Title: pattern }, { PositiveText: pattern }, { NegativeText: pattern }, { ReviewerName: pattern }];
    }

    return filter;
};

module.exports = buildFilter;
