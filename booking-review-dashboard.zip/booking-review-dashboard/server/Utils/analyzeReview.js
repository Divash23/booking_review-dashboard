const Sentiment = require("sentiment");

const sentimentAnalyzer = new Sentiment();

const TOPIC_KEYWORDS = {
    "Cleanliness": [
        "clean", "cleaning", "cleaned", "cleanliness", "dirty", "dust", "dusty", "stain", "stains", "stained",
        "hair", "hairs", "mould", "mold", "mouldy", "smell", "smelly", "smelled", "odour", "odor", "hygiene",
        "filthy", "spotless", "tidy", "cockroach", "cockroaches", "bugs", "bed bugs", "insects"
    ],
    "Check-in": [
        "check-in", "check in", "checkin", "checked in", "check-out", "check out", "checkout", "checked out",
        "arrival", "arrived", "key card", "keycard", "keys", "self check", "late check", "early check",
        "waited", "waiting", "queue", "reservation", "booking was", "lockbox", "code to"
    ],
    "Staff": [
        "staff", "reception", "receptionist", "receptionists", "front desk", "manager", "host", "team",
        "service", "rude", "friendly", "helpful", "unhelpful", "polite", "impolite", "attitude", "welcoming",
        "employee", "employees", "concierge"
    ],
    "Noise": [
        "noise", "noisy", "loud", "quiet", "thin walls", "traffic", "music", "party", "construction",
        "soundproof", "soundproofing", "could hear", "hear everything", "nightclub", "bar downstairs"
    ],
    "Facilities": [
        "wifi", "wi-fi", "internet", "lift", "elevator", "parking", "car park", "pool", "gym", "kitchen",
        "kitchenette", "laundry", "air conditioning", "air conditioner", "aircon", "air con", "heating",
        "heater", "tv", "facilities", "hot water", "water pressure", "breakfast", "fridge", "microwave",
        "kettle", "stairs"
    ],
    "Location": [
        "location", "located", "close to", "walk", "walking", "walking distance", "station", "transport",
        "train", "bus", "central", "nearby", "neighbourhood", "neighborhood", "area", "restaurants",
        "cafes", "shops", "convenient"
    ],
    "Room condition": [
        "room", "rooms", "bed", "beds", "mattress", "pillow", "pillows", "bathroom", "shower", "towel",
        "towels", "linen", "sheets", "furniture", "carpet", "window", "windows", "small", "tiny", "cramped",
        "spacious", "comfortable", "uncomfortable", "old", "outdated", "dated", "renovated", "renovation",
        "broken", "maintenance", "worn", "view", "balcony", "toilet"
    ],
    "Value for money": [
        "price", "prices", "priced", "value", "expensive", "overpriced", "cheap", "worth", "money",
        "cost", "rate", "affordable", "fee", "fees", "charge", "charged", "deposit", "budget"
    ]
};

const TOPICS = Object.keys(TOPIC_KEYWORDS);

const EMPTY_TEXT = /^(n\/?a|n a|none|nothing|nothing at all|nothing really|nil|no|-|\.|no comments?|no negative|no positive|there are no comments available for this review)\.?$/i;

const escapeRegex = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const TOPIC_PATTERNS = Object.fromEntries(
    TOPICS.map((topic) => [
        topic,
        new RegExp(`\\b(${TOPIC_KEYWORDS[topic].map(escapeRegex).join("|")})\\b`, "i")
    ])
);

const cleanText = (value) => {
    const text = String(value || "").replace(/\s+/g, " ").trim();
    return EMPTY_TEXT.test(text) ? "" : text;
};

const detectTopics = (value) => {
    const text = cleanText(value);
    if (!text) return [];
    return TOPICS.filter((topic) => TOPIC_PATTERNS[topic].test(text));
};

const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

const analyzeReview = ({ Title, PositiveText, NegativeText, Rating }) => {
    const rating = Number(Rating);
    const positive = cleanText(PositiveText);
    const negative = cleanText(NegativeText);
    const title = cleanText(Title);

    const score = (text) => (text ? sentimentAnalyzer.analyze(text).score : 0);
    let textScore = (score(positive) + score(negative) + score(title) * 0.5) / 6;
    if (negative) textScore -= 0.35;
    if (positive && !negative) textScore += 0.2;
    textScore = clamp(textScore, -1, 1);
    const ratingScore = clamp((rating - 6.5) / 3.5, -1, 1);
    const SentimentScore = Math.round((ratingScore * 0.7 + textScore * 0.3) * 100) / 100;

    let label = "Neutral";
    if (SentimentScore >= 0.2) label = "Positive";
    if (SentimentScore <= -0.2) label = "Negative";

    const titleTopics = detectTopics(title);
    const PraiseTopics = detectTopics(positive);
    let IssueTopics = detectTopics(negative);

    if (!positive && !negative && label === "Negative") {
        IssueTopics = titleTopics;
    }

    const Topics = TOPICS.filter(
        (topic) => PraiseTopics.includes(topic) || IssueTopics.includes(topic) || titleTopics.includes(topic)
    );

    return {
        Sentiment: label,
        SentimentScore,
        Topics,
        PraiseTopics,
        IssueTopics
    };
};

module.exports = { analyzeReview, detectTopics, cleanText, TOPICS };
