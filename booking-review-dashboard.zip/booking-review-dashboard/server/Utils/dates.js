const settings = require("../Config/settings");

const partsIn = (date, timeZone) => {
    const formatter = new Intl.DateTimeFormat("en-CA", {
        timeZone,
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hourCycle: "h23"
    });
    const parts = Object.fromEntries(formatter.formatToParts(date).map((part) => [part.type, part.value]));
    return {
        year: Number(parts.year),
        month: Number(parts.month),
        day: Number(parts.day),
        hour: Number(parts.hour),
        minute: Number(parts.minute),
        second: Number(parts.second)
    };
};

const offsetMs = (date, timeZone) => {
    const p = partsIn(date, timeZone);
    const asUtc = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second);
    return asUtc - Math.floor(date.getTime() / 1000) * 1000;
};

const zonedMidnight = ({ year, month, day }, timeZone = settings.timezone) => {
    const guess = Date.UTC(year, month - 1, day);
    let time = guess - offsetMs(new Date(guess), timeZone);
    time = guess - offsetMs(new Date(time), timeZone);
    return new Date(time);
};

const addDays = ({ year, month, day }, days) => {
    const d = new Date(Date.UTC(year, month - 1, day + days));
    return { year: d.getUTCFullYear(), month: d.getUTCMonth() + 1, day: d.getUTCDate() };
};

const formatDay = ({ year, month, day }) =>
    `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;

const localDay = (date = new Date(), timeZone = settings.timezone) => {
    const p = partsIn(date, timeZone);
    return { year: p.year, month: p.month, day: p.day };
};

const weekStartDay = (date = new Date(), timeZone = settings.timezone) => {
    const day = localDay(date, timeZone);
    const weekday = new Date(Date.UTC(day.year, day.month - 1, day.day)).getUTCDay();
    return addDays(day, -((weekday + 6) % 7));
};

const weekRange = (weeksBack = 0, timeZone = settings.timezone) => {
    const start = addDays(weekStartDay(new Date(), timeZone), -7 * weeksBack);
    const end = addDays(start, 7);
    return {
        key: formatDay(start),
        start: zonedMidnight(start, timeZone),
        end: zonedMidnight(end, timeZone)
    };
};

const parseDay = (value) => {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(value || ""));
    if (!match) return null;
    return { year: Number(match[1]), month: Number(match[2]), day: Number(match[3]) };
};

const dayStart = (value, timeZone = settings.timezone) => {
    const day = parseDay(value);
    return day ? zonedMidnight(day, timeZone) : null;
};

const dayEndExclusive = (value, timeZone = settings.timezone) => {
    const day = parseDay(value);
    return day ? zonedMidnight(addDays(day, 1), timeZone) : null;
};

const daysAgo = (days, timeZone = settings.timezone) => zonedMidnight(addDays(localDay(new Date(), timeZone), -days), timeZone);

module.exports = { weekRange, dayStart, dayEndExclusive, daysAgo, formatDay, localDay };
