const ReviewModel = require("../Model/Review.Model");
const PropertyModel = require("../Model/Property.Model");
const buildFilter = require("../Utils/buildFilter");
const settings = require("../Config/settings");
const { TOPICS } = require("../Utils/analyzeReview");
const { weekRange, daysAgo } = require("../Utils/dates");

const round = (value, places = 2) =>
    value === null || value === undefined ? null : Math.round(value * 10 ** places) / 10 ** places;

const percent = (part, total) => (total ? Math.round((part / total) * 1000) / 10 : 0);

const countIf = (field, value) => ({ $sum: { $cond: [{ $eq: [field, value] }, 1, 0] } });

const STATS_GROUP = {
    totalReviews: { $sum: 1 },
    averageRating: { $avg: "$Rating" },
    positiveReviews: countIf("$Sentiment", "Positive"),
    neutralReviews: countIf("$Sentiment", "Neutral"),
    negativeReviews: countIf("$Sentiment", "Negative")
};

const shapeStats = (row = {}) => {
    const total = row.totalReviews || 0;
    return {
        totalReviews: total,
        averageRating: round(row.averageRating),
        positiveReviews: row.positiveReviews || 0,
        neutralReviews: row.neutralReviews || 0,
        negativeReviews: row.negativeReviews || 0,
        positivePercentage: percent(row.positiveReviews || 0, total),
        negativePercentage: percent(row.negativeReviews || 0, total)
    };
};

const statsFor = async (match) => {
    const [row] = await ReviewModel.aggregate([{ $match: match }, { $group: { _id: null, ...STATS_GROUP } }]);
    return shapeStats(row);
};

const withRange = (filter, range) => ({ ...filter, ReviewDate: { $gte: range.start, $lt: range.end } });

const change = (current, previous) =>
    current !== null && previous !== null && current !== undefined && previous !== undefined ? round(current - previous) : null;

const topicLabel = (topic) => topic.toLowerCase();

const MIN_NEGATIVE_FOR_WEEK = 5;

const sendError = (response, error) =>
    response.status(/Invalid|must|Unknown/.test(error.message) ? 400 : 500).json({ message: error.message });

let DashboardController = {
    summary: async (request, response) => {
        try {
            let filter = buildFilter(request.query);
            let undated = buildFilter(request.query, { ignoreDates: true });
            let thisWeek = weekRange(0);
            let lastWeek = weekRange(1);

            let [overall, current, previous] = await Promise.all([
                statsFor(filter),
                statsFor(withRange(undated, thisWeek)),
                statsFor(withRange(undated, lastWeek))
            ]);

            return response.status(200).json({
                message: "Dashboard Summary",
                summary: {
                    ...overall,
                    currentWeek: { start: thisWeek.key, ...current },
                    previousWeek: { start: lastWeek.key, ...previous },
                    weeklyChange: change(current.averageRating, previous.averageRating)
                }
            });
        } catch (error) {
            return sendError(response, error);
        }
    },
    weeklyrating: async (request, response) => {
        try {
            let weeks = Math.min(52, Math.max(2, parseInt(request.query.weeks) || 8));
            let filter = buildFilter(request.query);
            if (!filter.ReviewDate) {
                filter.ReviewDate = { $gte: weekRange(weeks - 1).start };
            }

            let rows = await ReviewModel.aggregate([
                { $match: filter },
                {
                    $group: {
                        _id: {
                            week: {
                                $dateToString: {
                                    format: "%Y-%m-%d",
                                    date: { $dateTrunc: { date: "$ReviewDate", unit: "week", startOfWeek: "monday", timezone: settings.timezone } },
                                    timezone: settings.timezone
                                }
                            },
                            property: "$Property_id"
                        },
                        totalReviews: { $sum: 1 },
                        ratingSum: { $sum: "$Rating" },
                        positive: countIf("$Sentiment", "Positive"),
                        negative: countIf("$Sentiment", "Negative")
                    }
                },
                { $lookup: { from: "properties", localField: "_id.property", foreignField: "_id", as: "property" } },
                { $unwind: { path: "$property", preserveNullAndEmptyArrays: true } },
                { $sort: { "_id.week": 1 } }
            ]);

            let weekMap = {};
            rows.forEach((row) => {
                let key = row._id.week;
                if (!weekMap[key]) {
                    weekMap[key] = { Week: key, totalReviews: 0, ratingSum: 0, Positive: 0, Negative: 0 };
                }
                let week = weekMap[key];
                week[row.property ? row.property.Name : "Unknown"] = round(row.ratingSum / row.totalReviews);
                week.totalReviews += row.totalReviews;
                week.ratingSum += row.ratingSum;
                week.Positive += row.positive;
                week.Negative += row.negative;
            });

            let weeklyRating = Object.values(weekMap).map(({ ratingSum, ...week }) => ({
                ...week,
                Overall: round(ratingSum / week.totalReviews),
                NegativeShare: percent(week.Negative, week.totalReviews)
            }));

            return response.status(200).json({
                message: "Weekly Rating",
                weeklyRating
            });
        } catch (error) {
            return sendError(response, error);
        }
    },
    propertyperformance: async (request, response) => {
        try {
            let filter = buildFilter(request.query);
            delete filter.Property_id;
            let undated = buildFilter(request.query, { ignoreDates: true });
            delete undated.Property_id;

            let groupByProperty = (match) =>
                ReviewModel.aggregate([{ $match: match }, { $group: { _id: "$Property_id", ...STATS_GROUP } }]);

            let [properties, overall, current, previous, issues] = await Promise.all([
                PropertyModel.find().sort({ Name: 1 }).lean(),
                groupByProperty(filter),
                groupByProperty(withRange(undated, weekRange(0))),
                groupByProperty(withRange(undated, weekRange(1))),
                ReviewModel.aggregate([
                    { $match: filter },
                    { $unwind: "$IssueTopics" },
                    { $group: { _id: { property: "$Property_id", topic: "$IssueTopics" }, count: { $sum: 1 } } },
                    { $sort: { count: -1 } }
                ])
            ]);

            let index = (rows) => Object.fromEntries(rows.map((row) => [String(row._id), row]));
            let overallById = index(overall);
            let currentById = index(current);
            let previousById = index(previous);

            let performance = properties.map((p) => {
                let id = String(p._id);
                let stats = shapeStats(overallById[id]);
                let thisWeek = shapeStats(currentById[id]);
                let lastWeek = shapeStats(previousById[id]);
                let topIssue = issues.find((row) => String(row._id.property) === id);
                return {
                    Property_id: p._id,
                    Name: p.Name,
                    Location: p.Location,
                    BookingUrl: p.BookingUrl,
                    ...stats,
                    thisWeek: { averageRating: thisWeek.averageRating, totalReviews: thisWeek.totalReviews },
                    lastWeek: { averageRating: lastWeek.averageRating, totalReviews: lastWeek.totalReviews },
                    weeklyChange: change(thisWeek.averageRating, lastWeek.averageRating),
                    topIssue: topIssue
                        ? { Topic: topIssue._id.topic, count: topIssue.count, percentage: percent(topIssue.count, stats.totalReviews) }
                        : null
                };
            });

            return response.status(200).json({
                message: "Property Performance",
                performance
            });
        } catch (error) {
            return sendError(response, error);
        }
    },
    sentiment: async (request, response) => {
        try {
            let stats = await statsFor(buildFilter(request.query));
            let sentiment = [
                { Sentiment: "Positive", count: stats.positiveReviews },
                { Sentiment: "Neutral", count: stats.neutralReviews },
                { Sentiment: "Negative", count: stats.negativeReviews }
            ].map((item) => ({ ...item, percentage: percent(item.count, stats.totalReviews) }));

            return response.status(200).json({
                message: "Sentiment Analysis",
                sentiment,
                totalReviews: stats.totalReviews
            });
        } catch (error) {
            return sendError(response, error);
        }
    },
    topics: async (request, response) => {
        try {
            let filter = buildFilter(request.query);
            let unwindCount = (field) => [
                { $unwind: `$${field}` },
                { $group: { _id: `$${field}`, count: { $sum: 1 }, averageRating: { $avg: "$Rating" } } }
            ];

            let [result] = await ReviewModel.aggregate([
                { $match: filter },
                {
                    $facet: {
                        total: [{ $count: "count" }],
                        mentions: unwindCount("Topics"),
                        praise: unwindCount("PraiseTopics"),
                        issues: unwindCount("IssueTopics")
                    }
                }
            ]);

            let total = result.total[0] ? result.total[0].count : 0;
            let find = (list, topic) => list.find((row) => row._id === topic) || {};

            let topics = TOPICS.map((topic) => {
                let mention = find(result.mentions, topic);
                let praise = find(result.praise, topic).count || 0;
                let issues = find(result.issues, topic).count || 0;
                return {
                    Topic: topic,
                    mentions: mention.count || 0,
                    praise,
                    issues,
                    averageRating: round(mention.averageRating),
                    mentionShare: percent(mention.count || 0, total),
                    issueShare: percent(issues, total)
                };
            });

            return response.status(200).json({
                message: "Review Topics",
                totalReviews: total,
                topics
            });
        } catch (error) {
            return sendError(response, error);
        }
    },
    insights: async (request, response) => {
        try {
            let undated = buildFilter(request.query, { ignoreDates: true });
            let filter = buildFilter(request.query);
            let thisWeek = weekRange(0);
            let lastWeek = weekRange(1);

            let negativeIn = (range) => ({ ...withRange(undated, range), Sentiment: "Negative" });

            let issueCounts = (match) =>
                ReviewModel.aggregate([
                    { $match: match },
                    { $unwind: "$IssueTopics" },
                    { $group: { _id: "$IssueTopics", count: { $sum: 1 } } },
                    { $sort: { count: -1 } }
                ]);

            let periodLabel = "this week";
            let negativeMatch = negativeIn(thisWeek);
            let negativeCount = await ReviewModel.countDocuments(negativeMatch);

            if (negativeCount < MIN_NEGATIVE_FOR_WEEK) {
                periodLabel = "in the last 30 days";
                negativeMatch = { ...undated, Sentiment: "Negative", ReviewDate: { $gte: daysAgo(30) } };
                negativeCount = await ReviewModel.countDocuments(negativeMatch);
            }

            let [negativeIssues, current, previous, currentIssues, previousIssues, propertyRows, propertyIssues] = await Promise.all([
                issueCounts(negativeMatch),
                statsFor(withRange(undated, thisWeek)),
                statsFor(withRange(undated, lastWeek)),
                issueCounts(withRange(undated, thisWeek)),
                issueCounts(withRange(undated, lastWeek)),
                ReviewModel.aggregate([
                    { $match: filter },
                    { $group: { _id: "$Property_id", averageRating: { $avg: "$Rating" }, totalReviews: { $sum: 1 } } },
                    { $match: { totalReviews: { $gte: 3 } } },
                    { $lookup: { from: "properties", localField: "_id", foreignField: "_id", as: "property" } },
                    { $unwind: "$property" },
                    { $sort: { averageRating: -1 } }
                ]),
                ReviewModel.aggregate([
                    { $match: filter },
                    {
                        $group: {
                            _id: "$Property_id",
                            total: { $sum: 1 },
                            topics: { $push: "$IssueTopics" }
                        }
                    },
                    { $match: { total: { $gte: 5 } } },
                    { $lookup: { from: "properties", localField: "_id", foreignField: "_id", as: "property" } },
                    { $unwind: "$property" }
                ])
            ]);

            let issueBreakdown = negativeIssues.map((row) => ({
                Topic: row._id,
                count: row.count,
                percentage: percent(row.count, negativeCount)
            }));

            let share = (rows, topic, total) => percent((rows.find((r) => r._id === topic) || {}).count || 0, total);
            let risingIssues = TOPICS.map((topic) => ({
                Topic: topic,
                thisWeek: share(currentIssues, topic, current.totalReviews),
                lastWeek: share(previousIssues, topic, previous.totalReviews),
                count: (currentIssues.find((r) => r._id === topic) || {}).count || 0
            }))
                .map((row) => ({ ...row, change: round(row.thisWeek - row.lastWeek, 1) }))
                .filter((row) => row.count >= 2 && row.change >= 10 && previous.totalReviews > 0)
                .sort((a, b) => b.change - a.change);

            let byProperty = propertyIssues
                .map((row) => {
                    let counts = {};
                    row.topics.flat().forEach((topic) => {
                        counts[topic] = (counts[topic] || 0) + 1;
                    });
                    let [topic, count] = Object.entries(counts).sort((a, b) => b[1] - a[1])[0] || [];
                    return topic
                        ? { Name: row.property.Name, Topic: topic, count, percentage: percent(count, row.total) }
                        : null;
                })
                .filter(Boolean)
                .sort((a, b) => b.percentage - a.percentage);

            let toProperty = (row) =>
                row ? { Name: row.property.Name, averageRating: round(row.averageRating), totalReviews: row.totalReviews } : null;
            let bestProperty = toProperty(propertyRows[0]);
            let worstProperty = propertyRows.length > 1 ? toProperty(propertyRows[propertyRows.length - 1]) : null;

            let messages = [];

            if (current.totalReviews > 0 && previous.totalReviews > 0) {
                let diff = change(current.averageRating, previous.averageRating);
                let direction = diff > 0 ? "up" : diff < 0 ? "down" : "unchanged";
                messages.push({
                    tone: diff < 0 ? "bad" : "good",
                    text: `Average rating this week is ${current.averageRating}/10, ${direction}${diff ? ` ${Math.abs(diff)}` : ""} from ${previous.averageRating} last week (${current.totalReviews} reviews).`
                });
            } else if (current.totalReviews > 0) {
                messages.push({ tone: "info", text: `Average rating this week is ${current.averageRating}/10 from ${current.totalReviews} reviews. There were no reviews last week to compare with.` });
            } else {
                messages.push({ tone: "info", text: "No new reviews have been published this week yet." });
            }

            issueBreakdown.slice(0, 2).forEach((row) => {
                messages.push({
                    tone: "bad",
                    text: `${row.percentage}% of negative reviews ${periodLabel} mentioned ${topicLabel(row.Topic)}-related issues (${row.count} of ${negativeCount}).`
                });
            });

            risingIssues.slice(0, 2).forEach((row) => {
                messages.push({
                    tone: "bad",
                    text: `${row.Topic} complaints rose to ${row.thisWeek}% of reviews this week, up from ${row.lastWeek}% last week.`
                });
            });

            byProperty.slice(0, 2).forEach((row) => {
                messages.push({
                    tone: "info",
                    text: `At ${row.Name}, the most common complaint is ${topicLabel(row.Topic)} (${row.percentage}% of reviews in this period).`
                });
            });

            if (bestProperty && worstProperty && bestProperty.Name !== worstProperty.Name) {
                messages.push({
                    tone: "good",
                    text: `${bestProperty.Name} has the highest rating in this period (${bestProperty.averageRating}/10); ${worstProperty.Name} has the lowest (${worstProperty.averageRating}/10).`
                });
            }

            return response.status(200).json({
                message: "Review Insights",
                insights: {
                    period: periodLabel,
                    negativeReviews: negativeCount,
                    issueBreakdown,
                    risingIssues,
                    propertyIssues: byProperty,
                    bestProperty,
                    worstProperty,
                    messages
                }
            });
        } catch (error) {
            return sendError(response, error);
        }
    }
};

module.exports = DashboardController;
