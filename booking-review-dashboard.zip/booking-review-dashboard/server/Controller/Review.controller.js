const mongoose = require("mongoose");
const ReviewModel = require("../Model/Review.Model");
const buildFilter = require("../Utils/buildFilter");

const SORTS = {
    newest: { ReviewDate: -1, _id: -1 },
    oldest: { ReviewDate: 1, _id: 1 },
    lowest: { Rating: 1, ReviewDate: -1 },
    highest: { Rating: -1, ReviewDate: -1 }
};

let ReviewController = {
    getallreview: async (request, response) => {
        try {
            let filter = buildFilter(request.query);
            let page = Math.max(1, parseInt(request.query.page) || 1);
            let limit = Math.min(50, Math.max(1, parseInt(request.query.limit) || 12));
            let sort = SORTS[request.query.sort] || SORTS.newest;

            let [reviews, totalReviews] = await Promise.all([
                ReviewModel.find(filter)
                    .populate("Property_id", "Name Location")
                    .sort(sort)
                    .skip((page - 1) * limit)
                    .limit(limit)
                    .lean(),
                ReviewModel.countDocuments(filter)
            ]);

            return response.status(200).json({
                message: "All Review",
                reviews,
                totalReviews,
                page,
                totalPages: Math.ceil(totalReviews / limit)
            });
        } catch (error) {
            return response.status(400).json({
                message: error.message
            });
        }
    },
    getsinglereview: async (request, response) => {
        let { rid } = request.params;
        if (!mongoose.isValidObjectId(rid)) {
            return response.status(400).json({
                message: "Invalid review id"
            });
        }
        try {
            let review = await ReviewModel.findById(rid).populate("Property_id", "Name Location BookingUrl").lean();
            if (!review) {
                return response.status(404).json({
                    message: "Review Not Found"
                });
            }
            return response.status(200).json({
                message: "Review Details",
                review
            });
        } catch (error) {
            return response.status(500).json({
                message: error.message
            });
        }
    }
};

module.exports = ReviewController;
