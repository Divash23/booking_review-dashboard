const ScrapeRunModel = require("../Model/ScrapeRun.Model");
const ReviewModel = require("../Model/Review.Model");
const PropertyModel = require("../Model/Property.Model");
const { runScraper, runDatasetImport, isRunning } = require("../Scraper/runScraper");

let ScrapeController = {
    run: async (request, response) => {
        if (isRunning()) {
            return response.status(409).json({
                message: "A review update is already running"
            });
        }
        let { property, mode } = request.body || {};
        runScraper({ property, mode: mode === "full" ? "full" : "incremental" }).catch((error) =>
            console.log("Scrape Failed:", error.message)
        );
        return response.status(202).json({
            message: "Review update started"
        });
    },
    importdataset: async (request, response) => {
        if (isRunning()) {
            return response.status(409).json({
                message: "A review update is already running"
            });
        }
        let { limit, originalDates } = request.body || {};
        runDatasetImport({ limit, recent: !originalDates }).catch((error) =>
            console.log("Dataset Import Failed:", error.message)
        );
        return response.status(202).json({
            message: "Dataset import started"
        });
    },
    status: async (request, response) => {
        try {
            let properties = await PropertyModel.find().sort({ Name: 1 }).lean();
            let [lastRuns, lastReview, totalReviews, sources] = await Promise.all([
                Promise.all(
                    properties.map((p) =>
                        ScrapeRunModel.findOne({ Property_id: p._id, Status: { $ne: "running" } }).sort({ StartedAt: -1 }).lean()
                    )
                ),
                ReviewModel.findOne().sort({ FirstSeenAt: -1 }).select("FirstSeenAt").lean(),
                ReviewModel.countDocuments(),
                ReviewModel.aggregate([
                    { $group: { _id: "$Source", count: { $sum: 1 } } },
                    { $sort: { count: -1 } }
                ])
            ]);

            return response.status(200).json({
                message: "Scrape Status",
                running: isRunning(),
                totalReviews,
                lastNewReviewAt: lastReview ? lastReview.FirstSeenAt : null,
                sources: sources.map((s) => ({ Source: s._id, count: s.count, demo: /^Demo/.test(s._id || "") })),
                properties: properties.map((p, i) => ({
                    Property_id: p._id,
                    Name: p.Name,
                    lastRun: lastRuns[i]
                        ? {
                              Status: lastRuns[i].Status,
                              Source: lastRuns[i].Source,
                              FinishedAt: lastRuns[i].FinishedAt,
                              ReviewsInserted: lastRuns[i].ReviewsInserted,
                              Errors: lastRuns[i].Errors.slice(0, 3)
                          }
                        : null
                }))
            });
        } catch (error) {
            return response.status(500).json({
                message: error.message
            });
        }
    },
    history: async (request, response) => {
        try {
            let runs = await ScrapeRunModel.find().sort({ StartedAt: -1 }).limit(30).lean();
            return response.status(200).json({
                message: "Scrape History",
                runs
            });
        } catch (error) {
            return response.status(500).json({
                message: error.message
            });
        }
    }
};

module.exports = ScrapeController;
