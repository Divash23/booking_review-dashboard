const mongoose = require("mongoose");
const PropertyModel = require("../Model/Property.Model");
const ReviewModel = require("../Model/Review.Model");

let PropertyController = {
    getallproperty: async (request, response) => {
        try {
            let properties = await PropertyModel.find().sort({ Name: 1 }).lean();
            return response.status(200).json({
                message: "All Property",
                properties
            });
        } catch (error) {
            return response.status(500).json({
                message: error.message
            });
        }
    },
    getsingleproperty: async (request, response) => {
        let { pid } = request.params;
        if (!mongoose.isValidObjectId(pid)) {
            return response.status(400).json({
                message: "Invalid property id"
            });
        }
        try {
            let property = await PropertyModel.findById(pid).lean();
            if (!property) {
                return response.status(404).json({
                    message: "Property Not Found"
                });
            }
            let totalReviews = await ReviewModel.countDocuments({ Property_id: pid });
            return response.status(200).json({
                message: "Property Details",
                property,
                totalReviews
            });
        } catch (error) {
            return response.status(500).json({
                message: error.message
            });
        }
    }
};

module.exports = PropertyController;
