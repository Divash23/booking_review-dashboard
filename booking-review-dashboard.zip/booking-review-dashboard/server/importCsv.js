const fs = require("fs");
const mongoose = require("mongoose");
const { parse } = require("csv-parse/sync");
const Mongodb_Connection = require("./Config/db");
const ensureProperties = require("./Utils/ensureProperties");
const saveReviews = require("./Scraper/saveReviews");
const ScrapeRunModel = require("./Model/ScrapeRun.Model");
const { parseReviewDate, parseScore } = require("./Scraper/parseReviews");
const crypto = require("crypto");

const file = process.argv[2];

const pick = (row, ...names) => {
    for (const name of names) {
        const key = Object.keys(row).find((k) => k.trim().toLowerCase() === name);
        if (key && String(row[key]).trim()) return String(row[key]).trim();
    }
    return "";
};

const run = async () => {
    if (!file || !fs.existsSync(file)) {
        console.log("Usage: npm run import:csv -- path/to/reviews.csv");
        process.exit(1);
    }

    await Mongodb_Connection();
    const properties = await ensureProperties();
    const rows = parse(fs.readFileSync(file), { columns: true, skip_empty_lines: true, bom: true, trim: true });

    const byProperty = new Map();
    const problems = [];

    rows.forEach((row, index) => {
        const name = pick(row, "property", "hotel", "property_name").toLowerCase();
        const property = properties.find(
            (p) => p.Name.toLowerCase() === name || p.Slug === name || p.PageName === name
        );
        const Rating = parseScore(pick(row, "rating", "score"));
        const dateText = pick(row, "review_date", "date", "reviewed");
        const ReviewDate = parseReviewDate(dateText) || (dateText && !isNaN(new Date(dateText)) ? new Date(dateText) : null);

        if (!property) return problems.push(`row ${index + 2}: unknown property "${name}"`);
        if (!Rating) return problems.push(`row ${index + 2}: missing rating`);
        if (!ReviewDate) return problems.push(`row ${index + 2}: missing date`);

        const review = {
            ReviewerName: pick(row, "reviewer_name", "name", "guest") || "Anonymous",
            ReviewerCountry: pick(row, "reviewer_country", "country"),
            Title: pick(row, "title"),
            PositiveText: pick(row, "liked", "positive", "positive_text"),
            NegativeText: pick(row, "disliked", "negative", "negative_text"),
            Rating,
            ReviewDate,
            RoomType: pick(row, "room_type", "room"),
            StayDate: pick(row, "stay_date"),
            TravellerType: pick(row, "traveller_type", "traveler_type")
        };
        const id = pick(row, "review_id", "id");
        review.ExternalId = id
            ? `booking:${id}`
            : `hash:${crypto.createHash("sha1").update(JSON.stringify([property.PageName, review])).digest("hex")}`;

        if (!byProperty.has(property)) byProperty.set(property, []);
        byProperty.get(property).push(review);
    });

    for (const [property, reviews] of byProperty) {
        const saved = await saveReviews(property, reviews, "CSV import");
        await ScrapeRunModel.create({
            Property_id: property._id,
            PropertyName: property.Name,
            Source: "CSV import",
            Mode: "csv",
            Status: "success",
            Method: "csv",
            FinishedAt: new Date(),
            ReviewsFound: reviews.length,
            ReviewsInserted: saved.inserted,
            Duplicates: saved.duplicates
        });
        console.log(`${property.Name}: ${reviews.length} rows, ${saved.inserted} new, ${saved.duplicates} already saved`);
    }

    problems.forEach((p) => console.log(`! ${p}`));
    await mongoose.connection.close();
};

run().catch(async (error) => {
    console.log("CSV Import Failed:", error.message);
    await mongoose.connection.close();
    process.exit(1);
});
