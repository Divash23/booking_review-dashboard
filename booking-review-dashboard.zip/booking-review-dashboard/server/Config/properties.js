const PROPERTIES = [
    {
        Name: "Olympic Hotel Paddington",
        Slug: "olympic-paddington",
        PageName: "olympic-paddington",
        CountryCode: "au",
        Location: "Paddington, Sydney",
        BookingUrl: "https://www.booking.com/hotel/au/olympic-paddington.html"
    },
    {
        Name: "Potts Point",
        Slug: "potts-point",
        PageName: "venus-potts-point-sydney",
        CountryCode: "au",
        Location: "Potts Point, Sydney",
        BookingUrl: "https://www.booking.com/hotel/au/venus-potts-point-sydney.html"
    },
    {
        Name: "Central Sydney",
        Slug: "central-sydney",
        PageName: "venus-surry-hills",
        CountryCode: "au",
        Location: "Surry Hills, Sydney",
        BookingUrl: "https://www.booking.com/hotel/au/venus-surry-hills.html"
    },
    {
        Name: "Darling Harbour",
        Slug: "darling-harbour",
        PageName: "chateau-de-venus",
        CountryCode: "au",
        Location: "Darling Harbour, Sydney",
        BookingUrl: "https://www.booking.com/hotel/au/chateau-de-venus.html"
    }
];

module.exports = PROPERTIES;
