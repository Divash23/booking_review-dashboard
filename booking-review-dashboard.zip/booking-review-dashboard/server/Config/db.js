const mongoose = require("mongoose");
require("dotenv").config({ quiet: true });

const Mongodb_Connection = async () => {
    await mongoose.connect(process.env.Mongodb_Url);
};

module.exports = Mongodb_Connection;
