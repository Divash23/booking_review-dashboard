require("dotenv").config({ quiet: true });

const toNumber = (value, fallback) => {
    const number = Number(value);
    return Number.isFinite(number) && number > 0 ? number : fallback;
};

const settings = {
    port: toNumber(process.env.PORT || process.env.base_Port, 5050),
    timezone: process.env.TIMEZONE || "Australia/Sydney",
    bookingBaseUrl: (process.env.BOOKING_BASE_URL || "https://www.booking.com").replace(/\/$/, ""),
    reviewLanguage: process.env.REVIEW_LANGUAGE === undefined ? "en" : process.env.REVIEW_LANGUAGE,
    rowsPerPage: toNumber(process.env.SCRAPER_ROWS_PER_PAGE, 25),
    maxPagesIncremental: toNumber(process.env.SCRAPER_MAX_PAGES, 4),
    maxPagesFull: toNumber(process.env.SCRAPER_MAX_PAGES_FULL, 40),
    requestDelayMs: toNumber(process.env.SCRAPER_DELAY_MS, 2500),
    maxRetries: toNumber(process.env.SCRAPER_MAX_RETRIES, 3),
    requestTimeoutMs: toNumber(process.env.SCRAPER_TIMEOUT_MS, 20000),
    useBrowserFallback: process.env.SCRAPER_BROWSER_FALLBACK !== "false",
    scheduleMinutes: Number(process.env.SCRAPE_EVERY_MINUTES) || 0,
    datasetName: process.env.DATASET_NAME || "Dricz/515k-Hotel-Reviews-In-Europe"
};

module.exports = settings;
