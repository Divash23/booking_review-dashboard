const fs = require("fs");
const path = require("path");
const mongoose = require("mongoose");
const Mongodb_Connection = require("./Config/db");
const ReviewModel = require("./Model/Review.Model");
require("./Model/Property.Model");

const OUT_DIR = path.join(__dirname, "sample-data");

const COLUMNS = [
    "property", "review_date", "rating", "reviewer_name", "reviewer_country", "title", "liked", "disliked",
    "room_type", "stay_date", "nights", "traveller_type", "sentiment", "topics", "issue_topics", "source", "external_id"
];

const csvCell = (value) => {
    const text = value === undefined || value === null ? "" : String(value);
    return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
};

const run = async () => {
    await Mongodb_Connection();
    const reviews = await ReviewModel.find().populate("Property_id", "Name").sort({ ReviewDate: -1 }).lean();

    const rows = reviews.map((r) => ({
        property: r.Property_id ? r.Property_id.Name : "",
        review_date: r.ReviewDate.toISOString().slice(0, 10),
        rating: r.Rating,
        reviewer_name: r.ReviewerName,
        reviewer_country: r.ReviewerCountry,
        title: r.Title,
        liked: r.PositiveText,
        disliked: r.NegativeText,
        room_type: r.RoomType,
        stay_date: r.StayDate,
        nights: r.Nights,
        traveller_type: r.TravellerType,
        sentiment: r.Sentiment,
        topics: (r.Topics || []).join("; "),
        issue_topics: (r.IssueTopics || []).join("; "),
        source: r.Source,
        external_id: r.ExternalId
    }));

    fs.mkdirSync(OUT_DIR, { recursive: true });
    fs.writeFileSync(path.join(OUT_DIR, "reviews.json"), JSON.stringify(rows, null, 2));
    fs.writeFileSync(
        path.join(OUT_DIR, "reviews.csv"),
        [COLUMNS.join(","), ...rows.map((row) => COLUMNS.map((c) => csvCell(row[c])).join(","))].join("\n")
    );

    console.log(`Exported ${rows.length} reviews to sample-data/reviews.json and sample-data/reviews.csv`);
    await mongoose.connection.close();
};

run().catch(async (error) => {
    console.log("Export Failed:", error.message);
    await mongoose.connection.close();
    process.exit(1);
});
